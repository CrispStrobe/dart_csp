"""Preserve completed evidence with per-file hashes and deterministic archives.

Input must be a finalized evidence directory. Only explicitly named AOT
executables may be omitted; every other regular file is archived unchanged.
"""

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--kind', required=True)
    parser.add_argument('--source-ref', required=True)
    parser.add_argument('--note', required=True)
    parser.add_argument('--status-file', required=True)
    parser.add_argument('--omit-aot', action='append', default=[])
    args = parser.parse_args()
    status = json.loads((args.input / args.status_file).read_text())
    if status.get('status') != 'complete':
        raise SystemExit('Refusing to pack incomplete evidence: '+str(args.input))
    def git(ref):
        return subprocess.check_output(['git','rev-parse',ref],cwd=args.repo,text=True).strip()
    args.output.mkdir(parents=True, exist_ok=True)
    omitted = set(args.omit_aot)
    files = {}
    payload = {}
    all_paths = {}
    for path in sorted(args.input.rglob('*')):
        if path.is_symlink():
            raise SystemExit('Refusing unexpected symlink: '+str(path))
        if not path.is_file():
            continue
        name = path.relative_to(args.input).as_posix()
        all_paths[name] = path
        if name in omitted:
            if path.name != 'dart-adapter':
                raise SystemExit('Only prepared dart-adapter executables may be omitted')
            continue
        data = path.read_bytes()
        files[name] = {'bytes':len(data), 'sha256':sha256(data)}
        payload[name] = data
    if omitted - all_paths.keys():
        raise SystemExit('Missing declared AOT omissions: '+str(omitted - all_paths.keys()))
    if omitted:
        for name in sorted(omitted):
            variant = name.split('/')[0]
            recorded = status['variants'][variant]['executable_sha256']
            if sha256(all_paths[name].read_bytes()) != recorded:
                raise SystemExit('Omitted AOT executable does not match prepared manifest: '+name)
    archive = args.output / (args.kind+'.tar.gz')
    with archive.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=1) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as tar:
                for name,data in payload.items():
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    tar.addfile(info, io.BytesIO(data))
    archive_data=archive.read_bytes()
    manifest = {
        'schema_version':1, 'kind':args.kind, 'note':args.note,
        'saved_utc':datetime.now(timezone.utc).isoformat(),
        'source_commit':git(args.source_ref),
        'library_tree':git(args.source_ref+':lib'),
        'archive':archive.name, 'archive_bytes':len(archive_data),
        'archive_sha256':sha256(archive_data), 'files':files,
        'omitted_files':sorted(omitted),
        'omission_note':('Prepared native executables are identified by SHA-256 in prepared.json; source snapshots, compiler identity, build commands and logs are retained.' if omitted else None),
    }
    # Verify that the archive contains exactly the retained source bytes.
    with tarfile.open(archive, 'r:gz') as tar:
        names = set()
        for member in tar.getmembers():
            if not member.isfile():
                raise SystemExit('Unexpected archive member: '+member.name)
            data = tar.extractfile(member).read()
            if files[member.name] != {'bytes':len(data), 'sha256':sha256(data)}:
                raise SystemExit('Archive content verification failed: '+member.name)
            names.add(member.name)
        if names != set(files):
            raise SystemExit('Archive member set verification failed')
    manifest_path = args.output/(args.kind+'-evidence.json')
    manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'archive':str(archive),'archive_bytes':len(archive_data),'archive_sha256':manifest['archive_sha256'],'manifest':str(manifest_path),'manifest_bytes':manifest_path.stat().st_size,'retained_files':len(files),'omitted_files':manifest['omitted_files']},indent=2))

if __name__ == '__main__':
    main()
