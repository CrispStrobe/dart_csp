from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/c8c05a30f7ff')
REPO = ROOT / 'dart_csp'
OUT = ROOT / 'runtime/validation'
OUT.mkdir(parents=True, exist_ok=True)

def output(command):
    return subprocess.check_output(command, cwd=REPO, text=True).strip()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

result = {
    'started_at': datetime.now(timezone.utc).isoformat(),
    'status': 'running',
    'head': output(['git', 'rev-parse', 'HEAD']),
    'git_status': output(['git', 'status', '--short']),
    'dart_version': output(['dart', '--version']),
    'node_version': output(['node', '--version']),
    'chromium_version': output(['chromium', '--version']),
    'pubspec_lock_sha256': digest(REPO / 'pubspec.lock'),
    'sdk_archive_sha256': digest(ROOT / 'runtime/dartsdk-linux-x64-release.zip'),
    'source_sha256': {str(p.relative_to(REPO)): digest(p) for directory in ('lib', 'test') for p in sorted((REPO/directory).rglob('*.dart'))},
    'checks': [],
    'browser': {'status':'blocked_before_page_load', 'exit_code':134,
                'reason':'Chromium process singleton socket(): Operation not permitted',
                'log_sha256':digest(ROOT / 'runtime/chromium-startup.log')},
}
(OUT / 'chromium-startup.log').write_bytes((ROOT / 'runtime/chromium-startup.log').read_bytes())

def save():
    (OUT / 'manifest.json').write_text(json.dumps(result, indent=2)+'\n')

save()
checks = [
    ('format', ['dart', 'format', '--output=none', '--set-exit-if-changed', '.']),
    ('analysis', ['dart', 'analyze', '--fatal-infos']),
    ('sparse_tests', ['dart', 'test', '--reporter', 'expanded', 'test/geometry_sparse_ldlt_test.dart', 'test/geometry_sparse_policy_test.dart']),
    ('comparison_python', ['python3', '-m', 'unittest', 'discover', '-s', 'benchmark/solver_comparison', '-p', 'test_*.py', '-v']),
]
for name, command in checks:
    path = OUT / (name + '.log')
    started = time.monotonic()
    with path.open('w') as stream:
        process = subprocess.run(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT)
    check = {'name':name, 'command':command, 'exit_code':process.returncode, 'elapsed_s':time.monotonic()-started, 'log':path.name, 'log_sha256':digest(path)}
    result['checks'].append(check)
    save()
    print(json.dumps(check), flush=True)

result['status'] = 'complete' if all(c['exit_code'] == 0 for c in result['checks']) else 'failed'
result['completed_at'] = datetime.now(timezone.utc).isoformat()
save()
print(result['status'], flush=True)
raise SystemExit(0 if result['status'] == 'complete' else 1)
