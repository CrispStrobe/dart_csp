# Saved solver benchmark analysis

This report reads saved evidence only. It does not execute solvers or reinterpret geometry using a newer oracle. Detailed job records and source manifests are in analysis.json.

## Input provenance

| Run | Suite | Source commit | Jobs present / planned | Summary file |
| --- | --- | --- | --- | --- |
| run-001 | confirm,coupled | 6cc191f3e9a7 | 56/56 | summary.json |

Input directories:

- run-001: /workspace/scratch/c8c05a30f7ff/measurements/controls/after

## Completeness and physical outcomes

Accepted counts refer to the independent saved physical oracle. Native numerical success followed by physical rejection is a separate observation, not automatically an incorrect claim of hard feasibility. Missing operations and adapter exceptions receive no credit as successful rejection of contradictory inputs.

| Fixture | Engine | Mode | Complete jobs | Accepted / expected | Warmup accepted / expected | Valid rejections | Exceptions | Native success rejected | Oracle disagreements | Timeout jobs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ladder_25_components_1 | dart_2d_analytic | cold | 7/7 | 147/147 | 35/35 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_3d_ad | cold | 7/7 | 147/147 | 35/35 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_2d_analytic | warm | 7/7 | 147/147 | 35/35 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_3d_ad | warm | 7/7 | 147/147 | 35/35 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_2d_analytic | cold | 7/7 | 147/147 | 35/35 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_3d_ad | cold | 7/7 | 147/147 | 35/35 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_2d_analytic | warm | 7/7 | 147/147 | 35/35 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_3d_ad | warm | 7/7 | 147/147 | 35/35 | 0 | 0 | 0 | 0 | 0 |

## Qualified successful-solve latency

Each value is the median of per-process accepted-sample percentiles, giving each process equal weight. It is not a percentile of pooled observations. Both columns are withheld unless every included/planned job is complete and every measured sample is accepted, without oracle disagreement or incompatible build/request conditions. Warmups are counted above but excluded from latency.

A five-sample process p95 is its largest observation under the recorded upper-order statistic method. These tables do not establish stable p99 performance.

| Fixture | Engine | Mode | Processes | Median process p50 ms | Median process p95 ms | Max finite error / tolerance | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ladder_25_components_1 | dart_2d_analytic | cold | 7 | 2.85458 | 3.79582 | 0.961667 | qualified |
| ladder_25_components_1 | dart_3d_ad | cold | 7 | 4.85541 | 5.34543 | 0.961667 | qualified |
| ladder_25_components_1 | dart_2d_analytic | warm | 7 | 2.36652 | 2.63136 | 0.560966 | qualified |
| ladder_25_components_1 | dart_3d_ad | warm | 7 | 4.10878 | 5.25835 | 0.560966 | qualified |
| laman_free_100 | dart_2d_analytic | cold | 7 | 4.15769 | 5.34929 | 0.984891 | qualified |
| laman_free_100 | dart_3d_ad | cold | 7 | 6.30378 | 8.30359 | 0.984891 | qualified |
| laman_free_100 | dart_2d_analytic | warm | 7 | 3.62107 | 3.96993 | 0.913674 | qualified |
| laman_free_100 | dart_3d_ad | warm | 7 | 6.05496 | 6.34212 | 0.913674 | qualified |

## Reading limits

- Native adapter measurements exclude JSON, the external checker, browser/FFI integration and the full CAD application.
- Scalar coordinates are unfixed parameters before geometric constraints, not remaining DOF.
- Different sample or warmup counts per process are retained in JSON; select a consistent confirmation cohort when making a publication claim.
- Error ratios use each request tolerance. Missing/nonfinite errors are counted separately in JSON and are not silently converted into zero.
- Full manifests, binary/source hashes, archive hashes when read, per-job checksums, exclusions and optional engine metrics are in analysis.json.
