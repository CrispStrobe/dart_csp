"""Run frozen-source gates and checkpoint their logs after every command."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--dart', required=True)
p.add_argument('--output-dir', type=Path, required=True)
a = p.parse_args()
root, output = a.root.resolve(), a.output_dir.resolve()
output.mkdir(parents=True, exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

if git('status', '--porcelain', '--untracked-files=all', '--', 'lib', 'test'):
    raise SystemExit('Freeze source and tests before validation')

manifest = {
    'source_commit': git('rev-parse', 'HEAD'),
    'library_tree': git('rev-parse', 'HEAD:lib'),
    'test_tree': git('rev-parse', 'HEAD:test'),
    'runtime': subprocess.check_output([a.dart, '--version'], text=True).strip(),
    'node': subprocess.check_output(['node', '--version'], text=True).strip(),
    'platform': platform.platform(),
    'dependency_lock_sha256': hashlib.sha256((root / 'pubspec.lock').read_bytes()).hexdigest(),
    'package_config_sha256': hashlib.sha256((root / '.dart_tool/package_config.json').read_bytes()).hexdigest(),
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'running', 'steps': [],
}

def save():
    tmp = output / 'manifest.json.tmp'
    tmp.write_text(json.dumps(manifest, indent=2) + '\n')
    tmp.replace(output / 'manifest.json')

corpus = (root / 'tool/performance_cad_tests.txt').read_text().split()
browser = [
    'test/web_domain_rep_test.dart', 'test/compiled_session_test.dart',
    'test/geometry_preferences_test.dart', 'test/parametric_cad_test.dart',
    'test/incremental_assumption_snapshot_test.dart', 'test/lcg/atom_boundary_test.dart',
    'test/geometry_declaration_snapshot_test.dart', 'test/cad_document_snapshot_test.dart',
    'test/cad_profile_snapshot_test.dart', 'test/cad_mesh_link_storage_test.dart',
    'test/geometry_result_snapshot_test.dart', 'test/cad_placement_validation_path_test.dart',
    'test/cad_placement_precision_test.dart',
    'test/interval_rounding_test.dart',
]
steps = [
    ('format', [a.dart, 'format', '--output=none', '--set-exit-if-changed', '.'], 120),
    ('analyze', [a.dart, 'analyze', '--fatal-infos'], 600),
    ('native', [a.dart, 'test', '--reporter', 'expanded'], 900),
    ('node-js', [a.dart, 'test', '-p', 'node', '--compiler', 'dart2js', '--reporter', 'expanded', *corpus], 1200),
    ('node-wasm', [a.dart, 'test', '-p', 'node', '--compiler', 'dart2wasm', '--reporter', 'expanded', *corpus], 1200),
    ('browser', [a.dart, 'test', '-p', 'chrome', '--reporter', 'expanded', *browser], 600),
    ('runner-boundaries', [sys.executable, 'tool/test_compare_performance.py'], 120),
]
save()
for name, command, timeout in steps:
    print('START ' + name, flush=True)
    entry = {'name': name, 'command': command, 'cwd': str(root), 'timeout_seconds': timeout,
             'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'log': name + '.log'}
    start = time.monotonic()
    with (output / entry['log']).open('wb') as log:
        try:
            result = subprocess.run(command, cwd=root, env={**os.environ, 'CI': 'true', 'PYTHONDONTWRITEBYTECODE': '1'},
                                    stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            entry['exit_code'] = result.returncode
        except subprocess.TimeoutExpired:
            entry.update(exit_code=None, timed_out=True)
    entry.update(elapsed_seconds=time.monotonic() - start,
                 finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    data = (output / entry['log']).read_bytes()
    entry.update(log_sha256=hashlib.sha256(data).hexdigest(), log_bytes=len(data))
    manifest['steps'].append(entry)
    save()
    print('DONE ' + name + ' exit=' + str(entry['exit_code']) + '\n' + data.decode(errors='replace')[-500:], flush=True)
manifest['status'] = 'passed' if all(s['exit_code'] == 0 for s in manifest['steps']) else 'failed'
manifest['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest['source_unchanged'] = not git('diff', '--name-only', manifest['source_commit'], '--', 'lib', 'test')
save()
raise SystemExit(manifest['status'] != 'passed' or not manifest['source_unchanged'])
