// Frozen pre-fusion CG source from 2596d1d1ab08b7ea2f60b50427ce161f1ebfc6d4.
// Only the class/private helper names and imports differ from numeric.dart.
// This reference retains the separate geometryNorm(r) pass and public Jacobian calls.
import 'dart:typed_data';

import 'package:dart_csp/geometry.dart';

class BaselineSparseCgGeometrySolver implements GeometryLinearSolver {
  const BaselineSparseCgGeometrySolver();

  @override
  GeometryLinearStep solve(
    SparseGeometryJacobian jacobian,
    Float64List residual, {
    required double damping,
    required Float64List diagonal,
    int maxIterations = 1000,
    double relativeTolerance = 1e-8,
    bool Function()? shouldStop,
  }) {
    final n = jacobian.columns;
    final x = Float64List(n);
    final r = Float64List(n);
    jacobian.transposeMultiply(residual, r);
    for (var i = 0; i < n; i++) {
      r[i] = -r[i];
    }
    final initialNorm = geometryNorm(r);
    if (!initialNorm.isFinite) {
      return GeometryLinearStep(
        GeometryLinearStatus.numericalFailure,
        x,
        iterations: 0,
        relativeResidual: double.infinity,
      );
    }
    if (initialNorm == 0) {
      return GeometryLinearStep(
        GeometryLinearStatus.converged,
        x,
        iterations: 0,
        relativeResidual: 0,
      );
    }
    final preconditioner = Float64List(n);
    jacobian.normalDiagonal(preconditioner);
    final z = Float64List(n);
    final p = Float64List(n);
    final ap = Float64List(n);
    final jp = Float64List(jacobian.rows);
    var rz = 0.0;
    for (var i = 0; i < n; i++) {
      preconditioner[i] += damping * diagonal[i];
      if (!preconditioner[i].isFinite || preconditioner[i] <= 0) {
        return GeometryLinearStep(
          GeometryLinearStatus.numericalFailure,
          x,
          iterations: 0,
          relativeResidual: double.infinity,
        );
      }
      z[i] = r[i] / preconditioner[i];
      p[i] = z[i];
      rz += r[i] * z[i];
    }
    var relative = 1.0;
    var iterations = 0;
    for (; iterations < maxIterations; iterations++) {
      if (shouldStop?.call() ?? false) {
        return GeometryLinearStep(
          GeometryLinearStatus.cancelled,
          x,
          iterations: iterations,
          relativeResidual: relative,
        );
      }
      jacobian.multiply(p, jp);
      jacobian.transposeMultiply(jp, ap);
      var pap = 0.0;
      for (var i = 0; i < n; i++) {
        ap[i] += damping * diagonal[i] * p[i];
        pap += p[i] * ap[i];
      }
      if (!pap.isFinite || pap <= 0 || !rz.isFinite) {
        return GeometryLinearStep(
          GeometryLinearStatus.numericalFailure,
          x,
          iterations: iterations,
          relativeResidual: relative,
        );
      }
      final alpha = rz / pap;
      for (var i = 0; i < n; i++) {
        x[i] += alpha * p[i];
        r[i] -= alpha * ap[i];
      }
      relative = geometryNorm(r) / initialNorm;
      if (!relative.isFinite) {
        return GeometryLinearStep(
          GeometryLinearStatus.numericalFailure,
          x,
          iterations: iterations + 1,
          relativeResidual: relative,
        );
      }
      if (relative <= relativeTolerance) {
        // Recursive CG residuals can drift; verify against the original system.
        relative = _referenceNormalResidual(
          jacobian,
          residual,
          diagonal,
          damping,
          x,
        );
        if (relative <= relativeTolerance) {
          return GeometryLinearStep(
            GeometryLinearStatus.converged,
            x,
            iterations: iterations + 1,
            relativeResidual: relative,
          );
        }
        // Restart using the explicitly recomputed residual.
        jacobian.multiply(x, jp);
        for (var row = 0; row < jp.length; row++) {
          jp[row] += residual[row];
        }
        jacobian.transposeMultiply(jp, r);
        rz = 0.0;
        for (var i = 0; i < n; i++) {
          r[i] = -r[i] - damping * diagonal[i] * x[i];
          z[i] = r[i] / preconditioner[i];
          p[i] = z[i];
          rz += r[i] * z[i];
        }
        continue;
      }
      var nextRz = 0.0;
      for (var i = 0; i < n; i++) {
        z[i] = r[i] / preconditioner[i];
        nextRz += r[i] * z[i];
      }
      final beta = nextRz / rz;
      for (var i = 0; i < n; i++) {
        p[i] = z[i] + beta * p[i];
      }
      rz = nextRz;
    }
    relative = _referenceNormalResidual(
      jacobian,
      residual,
      diagonal,
      damping,
      x,
    );
    return GeometryLinearStep(
      relative <= relativeTolerance
          ? GeometryLinearStatus.converged
          : GeometryLinearStatus.iterationLimit,
      x,
      iterations: iterations,
      relativeResidual: relative,
    );
  }
}

double _referenceNormalResidual(
  SparseGeometryJacobian j,
  Float64List residual,
  Float64List diagonal,
  double damping,
  Float64List x, {
  void Function()? poll,
}) {
  if (poll != null) {
    return _referenceNormalResidualPolled(
      j,
      residual,
      diagonal,
      damping,
      x,
      poll,
    );
  }
  final temp = Float64List(j.rows);
  final out = Float64List(j.columns);
  final rhs = Float64List(j.columns);
  j.multiply(x, temp);
  for (var row = 0; row < temp.length; row++) {
    temp[row] += residual[row];
  }
  j.transposeMultiply(temp, out);
  j.transposeMultiply(residual, rhs);
  for (var i = 0; i < out.length; i++) {
    out[i] += damping * diagonal[i] * x[i];
  }
  final initial = geometryNorm(rhs);
  return initial == 0 ? geometryNorm(out) : geometryNorm(out) / initial;
}

double _referenceNormalResidualPolled(
  SparseGeometryJacobian j,
  Float64List residual,
  Float64List diagonal,
  double damping,
  Float64List x,
  void Function() poll,
) {
  final temp = Float64List(j.rows);
  final out = Float64List(j.columns);
  final rhs = Float64List(j.columns);
  for (var row = 0; row < j.rows; row++) {
    poll();
    var value = 0.0;
    for (var k = j.rowOffsets[row]; k < j.rowOffsets[row + 1]; k++) {
      poll();
      value += j.values[k] * x[j.columnIndices[k]];
    }
    temp[row] = value + residual[row];
  }
  for (var row = 0; row < j.rows; row++) {
    poll();
    for (var k = j.rowOffsets[row]; k < j.rowOffsets[row + 1]; k++) {
      poll();
      final column = j.columnIndices[k], value = j.values[k];
      out[column] += value * temp[row];
      rhs[column] += value * residual[row];
    }
  }
  for (var i = 0; i < out.length; i++) {
    poll();
    out[i] += damping * diagonal[i] * x[i];
  }
  final initial = geometryNorm(rhs), error = geometryNorm(out);
  if (!initial.isFinite || !error.isFinite) return double.infinity;
  return initial == 0 ? error : error / initial;
}
