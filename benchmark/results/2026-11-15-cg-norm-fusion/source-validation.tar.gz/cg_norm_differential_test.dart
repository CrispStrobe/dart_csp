import 'dart:typed_data';

import 'package:dart_csp/geometry.dart';
import 'package:test/test.dart';

import 'baseline_cg_reference.dart';

// Compare finite values and signed zero at the Float64 bit boundary. NaN
// payloads are not a portable Dart contract; their classification is checked.
String _bits(double value) {
  if (value.isNaN) return 'NaN';
  final bytes = ByteData(8)..setFloat64(0, value, Endian.little);
  return '${bytes.getUint32(4, Endian.little).toRadixString(16)}:'
      '${bytes.getUint32(0, Endian.little).toRadixString(16)}';
}

List<String> _vectorBits(List<double> values) => values.map(_bits).toList();

void _sameResult(
  GeometryLinearStep actual,
  GeometryLinearStep expected, {
  required String reason,
}) {
  expect(actual.status, expected.status, reason: reason);
  expect(actual.iterations, expected.iterations, reason: reason);
  expect(
    _bits(actual.relativeResidual),
    _bits(expected.relativeResidual),
    reason: reason,
  );
  expect(_vectorBits(actual.step), _vectorBits(expected.step), reason: reason);
}

class _TracingJacobian extends SparseGeometryJacobian {
  _TracingJacobian({
    required super.rows,
    required super.columns,
    required super.rowOffsets,
    required super.columnIndices,
    required super.values,
  });

  final trace = <String>[];

  @override
  void normalDiagonal(Float64List out) {
    trace.add('diagonal');
    super.normalDiagonal(out);
  }

  @override
  void multiply(Float64List x, Float64List out) {
    trace.add('multiply:${_vectorBits(x)}');
    super.multiply(x, out);
  }

  @override
  void transposeMultiply(Float64List x, Float64List out) {
    trace.add('transpose:${_vectorBits(x)}');
    super.transposeMultiply(x, out);
  }
}

(GeometryLinearStep, List<String>, int) _solveCsr(
  GeometryLinearSolver solver, {
  required int n,
  required double scale,
  required double damping,
  required int budget,
  required int? stopAt,
  required bool mutate,
}) {
  final offsets = <int>[0];
  final indices = <int>[];
  final values = <double>[];
  for (var i = 0; i < n; i++) {
    indices.add(i);
    values.add(scale * (1 + .125 * (i % 3)));
    offsets.add(indices.length);
  }
  for (var i = 0; i + 1 < n; i++) {
    // Unsorted duplicates plus a neighboring column; the anchored system
    // remains positive definite and exercises multiple CG iterations.
    indices.addAll([i + 1, i, i]);
    values.addAll([-.375 * scale, .5 * scale, -.25 * scale]);
    offsets.add(indices.length);
  }
  offsets.add(indices.length); // Empty row.
  final jacobian = _TracingJacobian(
    rows: offsets.length - 1,
    columns: n,
    rowOffsets: Int32List.fromList(offsets),
    columnIndices: Int32List.fromList(indices),
    values: Float64List.fromList(values),
  );
  final residual = Float64List.fromList([
    for (var row = 0; row < jacobian.rows; row++)
      scale * (((row * 7) % 13) - 6) / 7,
  ]);
  final diagonal = Float64List.fromList([
    for (var i = 0; i < n; i++) .5 + (i % 5),
  ]);
  var polls = 0;
  final result = solver.solve(
    jacobian,
    residual,
    damping: damping * scale * scale,
    diagonal: diagonal,
    maxIterations: budget,
    relativeTolerance: 1e-12,
    shouldStop: () {
      polls++;
      jacobian.trace.add('poll:$polls');
      if (mutate && polls == 2) {
        jacobian.values[0] *= 1.125;
        diagonal.last *= 2;
      }
      return polls == stopAt;
    },
  );
  return (result, jacobian.trace, polls);
}

void main() {
  const candidate = SparseCgGeometrySolver();
  const baseline = BaselineSparseCgGeometrySolver();
  group('CG norm source equivalence', () {
    test(
      'matches frozen CG results and public callback inputs across CSR cases',
      () {
        var compared = 0;
        var converged = 0;
        var multipleIterations = 0;
        for (final n in [3, 8, 17]) {
          for (final scale in [1e-100, 1.0, 1e100]) {
            for (final damping in [0.0, .125, 4.0]) {
              for (final budget in [0, 1, 2, n + 3]) {
                for (final stopAt in <int?>[null, 1, 3]) {
                  for (final mutate in [false, true]) {
                    final (actual, trace, polls) = _solveCsr(
                      candidate,
                      n: n,
                      scale: scale,
                      damping: damping,
                      budget: budget,
                      stopAt: stopAt,
                      mutate: mutate,
                    );
                    final (
                      expected,
                      referenceTrace,
                      referencePolls,
                    ) = _solveCsr(
                      baseline,
                      n: n,
                      scale: scale,
                      damping: damping,
                      budget: budget,
                      stopAt: stopAt,
                      mutate: mutate,
                    );
                    final reason =
                        'n=$n scale=$scale damping=$damping '
                        'budget=$budget stopAt=$stopAt mutate=$mutate';
                    _sameResult(actual, expected, reason: reason);
                    expect(trace, referenceTrace, reason: reason);
                    expect(polls, referencePolls, reason: reason);
                    compared++;
                    if (actual.status == GeometryLinearStatus.converged) {
                      converged++;
                    }
                    if (actual.iterations > 1) {
                      multipleIterations++;
                    }
                  }
                }
              }
            }
          }
        }
        expect(compared, 648);
        expect(converged, greaterThan(0));
        expect(multipleIterations, greaterThan(0));
      },
    );
  });
}
