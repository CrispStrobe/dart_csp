# One-off CG norm source-equivalence evidence

The permanent candidate adds three public-contract tests only. The copied
pre-fusion CG implementation is preserved here solely as verification evidence.
The manifest records its exact source, validated extraction transformation,
unchanged norm helper, candidate hash, executed command and all 648 cases.

The recorded focused command ran three permanent norm-contract tests plus one
differential test entry and passed all four. The differential entry compares
648 CSR configurations: extreme scales, duplicate/unsorted entries, empty rows,
iteration budgets, cancellation and callback mutations. It compares statuses,
iterations, finite/zero bit patterns, NaN classification, public Jacobian method
inputs/order and poll counts. This is not exhaustive branch coverage or timing.

## Replay

Use a checkout whose numeric.dart matches the manifest candidate hash, with
pinned Dart 3.14.0 and resolved dependencies. From that checkout run the pinned
Dart executable with `test`, the absolute path to this directory's
`cg_norm_differential_test.dart`, and `--reporter expanded`. Use a writable
TMPDIR and the resolved PUB_CACHE. The reference import is relative to this
evidence directory. The exact original command (also including the three
package tests), cwd and environment are in manifest.json.

Keep this evidence archived under benchmark results, outside the package's
persistent test-support tree.
