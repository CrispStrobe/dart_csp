"""Non-timed assembly/linkage harness and synthetic auditor validation."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

WORKSPACE = Path('/workspace/scratch/822c041c6436')
ROOT = WORKSPACE / 'dart_csp_tail_harness'
DART = str(WORKSPACE / 'toolchain/dart-sdk/bin/dart')
ENV = dict(os.environ, PUB_CACHE=str(WORKSPACE / 'pub-cache'),
           TMPDIR=str(WORKSPACE / 'tmp'), DART_DISABLE_ANALYTICS='true',
           PYTHONDONTWRITEBYTECODE='1')
records = []


def invoke(label, command, expected=0):
    done = subprocess.run(command, cwd=ROOT, env=ENV, capture_output=True,
                          timeout=60)
    record = {'label': label, 'command': command, 'exit_code': done.returncode}
    for stream in ('stdout', 'stderr'):
        raw = getattr(done, stream)
        record[stream] = raw.decode('utf-8', errors='surrogateescape')
        record[stream + '_sha256'] = hashlib.sha256(raw).hexdigest()
    records.append(record)
    if done.returncode != expected:
        raise AssertionError(record)
    return record


invoke('fatal-info analysis', [DART, 'analyze', '--fatal-infos',
       'benchmark/cad_instances.dart', 'benchmark/cad_linkage.dart'])
invoke('format check', [DART, 'format', '--output=none', '--set-exit-if-changed',
       'benchmark/cad_instances.dart', 'benchmark/cad_linkage.dart'])
checked = invoke('assembly check-only; no harness Stopwatch',
                 [DART, 'run', 'benchmark/cad_instances.dart', '--check-only'])
assembly = json.loads(checked['stdout'])
assert assembly['check_only'] and not assembly['operation_tracing_enabled']
assert (assembly['measured_pairs'], assembly['warmup_pairs']) == (2, 0)
for case in ('cold_build_solve_regenerate', 'solved_pose_edit'):
    assert assembly[case]['samples_us'] == [0, 0]
    assert [work['gap'] for work in assembly[case]['work_per_sample']] == [12, 5]
invoke('linkage check-only; no harness Stopwatch',
       [DART, 'run', 'benchmark/cad_linkage.dart', '--check-only'])
invoke('legacy controls audit', [sys.executable, '-B', 'tool/audit_cad_measurements.py',
       'benchmark/results/2026-11-14-controls-paired.json.gz',
       'benchmark/results/2026-11-14-controls-summary.json', '--output',
       str(WORKSPACE / 'audit-evidence/tail-harness-legacy-audit.json')])

spec = importlib.util.spec_from_file_location('summarizer', ROOT / 'tool/summarize_performance.py')
summarizer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(summarizer)
fixture = copy.deepcopy(assembly)
fixture['check_only'] = False
for case in ('cold_build_solve_regenerate', 'solved_pose_edit'):
    fixture[case].update(samples_us=[9, 3], p50=9, p95=9, p99=9)
raw = {
    'synthetic_validation_only': True,
    'rounds': 1,
    'harnesses': {'cad_instances': {'file': 'benchmark/cad_instances.dart'}},
    'revisions': {label: {'commit': 'synthetic-not-a-source-revision',
                         'library_diff_sha256': None} for label in ('before', 'after')},
    'runs': [{'mode': mode, 'benchmark': 'cad_instances', 'revision': revision,
              'round': 1, 'arguments': ['--samples=2', '--warmups=0'],
              'result': copy.deepcopy(fixture)}
             for mode in ('jit', 'aot') for revision in ('before', 'after')],
}

with tempfile.TemporaryDirectory(prefix='tail-harness-audit-', dir=WORKSPACE / 'tmp') as directory:
    directory = Path(directory)
    source, summary, report = [directory / name for name in ('synthetic.json', 'summary.json', 'audit.json')]

    def audit(label, candidate, expected=0):
        source.write_text(json.dumps(candidate))
        summary.write_text(json.dumps({'source': source.name,
            'revisions': candidate['revisions'], 'rows': summarizer.summarize(candidate)}))
        invoke(label, [sys.executable, '-B', 'tool/audit_cad_measurements.py',
                      str(source), str(summary), '--output', str(report)], expected)
        return json.loads(report.read_text())

    audit('synthetic ordered samples and paired physical work accepted', raw)
    mutations = {
        'diagnostic trace rejected': lambda r: r.update(operation_tracing_enabled=True),
        'check-only data rejected': lambda r: r.update(check_only=True),
        'bad p99 rejected': lambda r: r['solved_pose_edit'].update(p99=10),
        'unaligned work rejected': lambda r: r['solved_pose_edit']['work_per_sample'].pop(),
        'wrong gap rejected': lambda r: r['solved_pose_edit']['work_per_sample'][0].update(gap=5),
        'unexpected extrusion rejected': lambda r: r['solved_pose_edit']['work_per_sample'][0].update(extrusions=1),
        'stale solve rejected': lambda r: r['solved_pose_edit']['work_per_sample'][0].update(geometry_solve_invoked=False),
        'missing raw samples rejected': lambda r: r['solved_pose_edit'].pop('samples_us'),
    }
    for label, mutate in mutations.items():
        candidate = copy.deepcopy(raw)
        mutate(candidate['runs'][0]['result'])
        assert audit('synthetic ' + label, candidate, expected=1)['status'] == 'failed'

paths = ['benchmark/cad_instances.dart', 'benchmark/cad_linkage.dart',
         'tool/audit_cad_measurements.py', 'tool/compare_performance.py']
output = WORKSPACE / 'audit-evidence/tail-harness-validation.json'
output.write_text(json.dumps({
    'status': 'passed',
    'scope': 'Static checks, non-timed correctness runs, legacy audit and synthetic auditor fixtures only. No elapsed-time benchmark or profiling workload was run. Synthetic timings 9/3 are invented test data, not measurements.',
    'source_sha256': {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in paths},
    'records': records,
}, indent=2) + '\n')
print(f'Passed {len(records)} validation commands; evidence: {output}')
