import 'dart:convert';
import 'dart:typed_data';
import 'package:dart_csp/cad.dart';

(int, int, int, int) fingerprint(CadMesh mesh) {
  var first = 0, second = 0;
  final bytes = ByteData(8);
  void add(int value) {
    first = (first * 31 + value) & 0x7fffffff;
    second = (second * 131 + value) & 0x7fffffff;
  }
  void integer(int value) {
    bytes.setUint32(0, value);
    for (var i = 0; i < 4; i++) add(bytes.getUint8(i));
  }
  integer(mesh.vertices.length);
  integer(mesh.triangles.length);
  for (final point in mesh.vertices) {
    for (final coordinate in [point.x, point.y, point.z]) {
      bytes.setFloat64(0, coordinate);
      for (var i = 0; i < 8; i++) add(bytes.getUint8(i));
    }
  }
  for (final triangle in mesh.triangles) {
    integer(triangle.a); integer(triangle.b); integer(triangle.c);
    integer(triangle.faceId.length);
    for (final unit in triangle.faceId.codeUnits) integer(unit);
  }
  return (mesh.vertices.length, mesh.triangles.length, first, second);
}

List<(String, CadRectangularProfile, double, double)> fixtures() => [
 ('box', CadRectangularProfile(width: 4, height: 6), 2, 0.03),
 ('offset_holes', CadRectangularProfile(width: 20, height: 10, holes: const [
   CadCircularHole(id:'left', centerX:-4, centerY:-1, radius:0.75),
   CadCircularHole(id:'right', centerX:4, centerY:2, radius:1.25),
 ]), 2, 0.01),
 ('positive_zero', CadRectangularProfile(width:4, height:2, holes: const [
   CadCircularHole(id:'mount', centerX:0.0, centerY:0.0, radius:0.5),
 ]), 0.5, 0.03),
 ('negative_zero', CadRectangularProfile(width:4, height:2, holes: const [
   CadCircularHole(id:'mount', centerX:-0.0, centerY:-0.0, radius:0.5),
 ]), 0.5, 0.03),
 ('unresolved_area', CadRectangularProfile(width:1e308, height:1e-308), 1, 0.03),
];

void main() {
 const kernel = ReferenceCadKernel();
 final results=<String,Object>{};
 for(final (name,profile,depth,chordError) in fixtures()) {
   final body=kernel.extrude(featureId:name,profile:profile,depth:depth);
   if(!body.isSuccess) throw StateError('Unexpected extrusion $name: ${body.issues}');
   final result=kernel.tessellate(body.value!,chordError:chordError);
   results[name]=result.isSuccess ? {'fingerprint':fingerprint(result.value!).toString(), 'issues':[]} : {'status':result.status.name,'issues':[for(final i in result.issues) [i.code,i.entity]]};
 }
 print(jsonEncode(results));
}
