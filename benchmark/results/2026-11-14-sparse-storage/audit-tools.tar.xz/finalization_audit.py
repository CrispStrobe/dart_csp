#!/usr/bin/env python3
"""Audit frozen paired evidence without running solvers or changing raw files.

The preserved audit is imported for its read-only directory/archive reader.
This extension additionally handles honest feasible-case rejection/deadlines,
checks terminal manifests, paired requests, complete group ratios, and keeps
reliability outcomes separate from evidence-integrity errors.
"""
import argparse
import collections
import datetime
import gzip
import hashlib
import importlib.util
import io
import json
import math
from pathlib import Path
import statistics
import subprocess

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    'preserved_audit', BASE / 'independent-audit-preserved.py')
preserved = importlib.util.module_from_spec(spec)
spec.loader.exec_module(preserved)
Reader = preserved.Reader
digest = preserved.digest


def percentile(values, fraction):
    ordered = sorted(values)
    return ordered[math.ceil((len(ordered) - 1) * fraction)] if ordered else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--prepared', required=True)
    parser.add_argument('--run', required=True)
    args = parser.parse_args()
    report = dict(schema_version=1, errors=[], source={}, counts={}, groups=[],
                  note='Feasible rejection or timeout is a reliability outcome; '
                       'errors contains evidence inconsistencies only.')

    def require(condition, label):
        if not condition:
            report['errors'].append(label)

    prep, run = Reader(path=args.prepared), Reader(path=args.run)
    preparation_bytes = prep.read('prepared.json')
    preparation = json.loads(preparation_bytes)
    manifest = run.json('manifest.json')
    require(preparation['status'] == 'complete', 'preparation complete')
    require(manifest['status'] == 'complete', 'run terminal status')
    require('in_progress' not in manifest, 'no unfinished in_progress marker')
    require(digest(preparation_bytes) == manifest['prepared_manifest_sha256'],
            'prepared manifest identity')
    require(manifest['preparation'] == preparation, 'embedded preparation identity')
    require(manifest['harness_sha256'] == preparation['harness_sha256'],
            'harness manifest identities')
    for name, expected in preparation['harness_sha256'].items():
        require(digest(prep.read('harness/' + name)) == expected, 'harness ' + name)
    oracle = {}
    exec(compile(prep.read('harness/oracle.py'), 'saved-oracle.py', 'exec'), oracle)
    for variant, item in preparation['variants'].items():
        source = item['source']
        report['source'][variant] = {key: source[key] for key in (
            'source_commit', 'source_tree', 'library_tree', 'test_tree')}
        archived = prep.read(item['source_archive'])
        require(digest(archived) == item['source_archive_sha256'], variant + ' source archive')
        src = Reader(data=archived)
        require(set(src.names()) == set(source['source_sha256']), variant + ' source member set')
        for path, expected in source['source_sha256'].items():
            require(digest(src.read(path)) == expected, variant + ' source ' + path)
        for key, suffix in [('source_tree', '^{tree}'), ('library_tree', ':lib'), ('test_tree', ':test')]:
            actual = subprocess.check_output(['git', '-C', str(args.repo), 'rev-parse',
                source['source_commit'] + suffix], text=True).strip()
            require(actual == source[key], variant + ' ' + key)
        if item['executable'] in prep.names():
            require(digest(prep.read(item['executable'])) == item['executable_sha256'],
                    variant + ' executable')
        for kind in ['stdout', 'stderr']:
            require(digest(prep.read(variant + '/build.' + kind + '.log')) ==
                    item['build'][kind + '_sha256'], variant + ' build ' + kind)

    counts = collections.defaultdict(collections.Counter)
    jobs = {}
    groups = collections.defaultdict(list)
    pairs = collections.defaultdict(dict)
    reports = []
    for name in sorted(n for n in run.names() if n.endswith('/job.json')):
        prefix = name.rsplit('/', 1)[0]
        job = run.json(name)
        variant = job['variant']
        require(prefix.split('/')[0] == variant, name + ' variant')
        jobs[prefix] = job
        req_bytes = gzip.decompress(run.read(prefix + '/request.json.gz'))
        request = json.loads(req_bytes)
        require(digest(req_bytes) == job['request_sha256'], name + ' request hash')
        physical = {k: v for k, v in request.items() if k != 'engine'}
        physical_hash = digest(json.dumps(physical, sort_keys=True,
            separators=(',', ':'), allow_nan=False).encode())
        require(physical_hash == job['physical_request_sha256'], name + ' physical request hash')
        require(digest(json.dumps(job['command']).encode()) == job['command_sha256'],
                name + ' command hash')
        checked = run.jsonl(prefix + '/checked.jsonl.gz')
        raw = gzip.decompress(run.read(prefix + '/stdout.jsonl.gz'))
        native, malformed = [], []
        for index, line in enumerate(raw.splitlines()):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except ValueError:
                malformed.append(index)
                continue
            if record.get('record') != 'metadata':
                native.append(record)
        require(not malformed or bool(job['parse_errors']), name + ' raw parse errors recorded')
        require(len(native) == len(checked), name + ' native record count')
        require([r['index'] for r in native] ==
                list(range(-request['warmups'], -request['warmups'] + len(native))),
                name + ' contiguous native indices')
        expected_records = request['warmups'] + request['samples']
        complete = (not job['timed_out'] and job['returncode'] == 0 and
                    not job['parse_errors'] and len(native) == expected_records)
        require(complete == job['summary']['complete'], name + ' completeness')
        require(expected_records == job['summary']['expected_records'], name + ' expected records')
        require(len(native) == job['summary']['completed_records'], name + ' completed records')
        c = counts[variant]
        c['jobs'] += 1
        c['complete_jobs'] += complete
        c['timeouts'] += bool(job['timed_out'])
        c['nonzero_exits'] += job['returncode'] not in (0, None)
        c['parse_error_jobs'] += bool(job['parse_errors'])
        c['missing_operations'] += expected_records - len(native)
        failures = 0
        for original, saved in zip(native, checked):
            require(original == {k: v for k, v in saved.items() if k != 'oracle'},
                    name + ' native fields ' + str(original['index']))
            require(original['warmup'] == (original['index'] < 0), name + ' warmup identity')
            require(original['engine'] == request['engine'] and original['mode'] == request['mode']
                    and original['fixture_id'] == request['fixture']['id'], name + ' record identity')
            actual = oracle['check'](request, original)
            if request['engine'] == 'dart_3d_ad' and original.get('max_z', 0) > request['tolerance']:
                actual['accepted'] = False
                actual['violations'].append('workplane_z')
            require(actual == saved['oracle'], name + ' oracle ' + str(original['index']))
            expected = request['fixture']['expected_feasible']
            c['records'] += 1
            c['warmups'] += original['warmup']
            c['accepted'] += actual['accepted']
            c['rejected'] += not actual['accepted']
            c['feasible_rejected'] += expected and not actual['accepted']
            c['contradictions_rejected'] += not expected and not actual['accepted']
            c['adapter_errors'] += bool(original.get('adapter_error'))
            c['acceptance_disagreements'] += bool(original['accepted']) != actual['accepted']
            mismatch = bool(original.get('adapter_error')) or actual['accepted'] != expected
            failures += mismatch
            c['qualification_mismatches'] += mismatch
        require(failures == job['qualification_operation_failures'], name + ' qualification failures')
        measured = [r for r in checked if not r['warmup']]
        accepted = [r for r in measured if r['oracle']['accepted']]
        require(len(measured) == job['summary']['completed_samples'], name + ' sample count')
        require(len(accepted) == job['summary']['accepted_samples'], name + ' accepted count')
        require(len(measured) - len(accepted) == job['summary']['rejected_samples'], name + ' rejected count')
        for label, rows in [('all', measured), ('accepted', accepted)]:
            for stat, fraction in [('p50', .5), ('p95', .95)]:
                value = percentile([r['elapsed_ns'] / 1e6 for r in rows], fraction)
                require(value == job['summary'][label + '_' + stat + '_ms'], name + ' ' + label + '_' + stat)
        key = (job['fixture_id'], job['engine'], job['mode'])
        groups[(variant, *key)].append(job)
        pair_key = (*key, job['round'])
        pairs[pair_key][variant] = dict(physical_hash=physical_hash, records=checked, job=job)
        reports.append(dict(variant=variant, fixture_id=job['fixture_id'], engine=job['engine'],
            mode=job['mode'], round=job['round'], complete=complete, timed_out=job['timed_out'],
            expected_records=expected_records, completed_records=len(checked),
            accepted_records=sum(r['oracle']['accepted'] for r in checked),
            statuses=dict(collections.Counter(r.get('status') for r in checked)),
            all_p50_ms=job['summary']['all_p50_ms'], all_p95_ms=job['summary']['all_p95_ms'],
            diagnostic_latency_only=not (complete and len(accepted) == request['samples'])))

    expected_jobs = len(manifest['variants']) * len(manifest['fixture_ids']) * len(manifest['engines']) * len(manifest['modes']) * manifest['rounds']
    require(len(jobs) == expected_jobs, 'expected job count')
    require(len(manifest['jobs']) == expected_jobs, 'top manifest job count')
    last_end = None
    for listed in manifest['jobs']:
        prefix = listed['variant'] + '/' + listed['job']
        require(prefix in jobs, 'top manifest raw job ' + prefix)
        if prefix not in jobs:
            continue
        job = jobs[prefix]
        require(listed['summary'] == job['summary'], 'top manifest job summary ' + prefix)
        start = datetime.datetime.fromisoformat(job['started_utc'])
        end = datetime.datetime.fromisoformat(job['completed_utc'])
        require(start <= end and (last_end is None or last_end <= start), 'sequential jobs ' + prefix)
        last_end = end
    for variant in manifest['variants']:
        lane = run.json(variant + '/manifest.json')
        require(lane['status'] == 'complete', variant + ' terminal status')
        require(lane['completed_jobs'] == counts[variant]['jobs'], variant + ' completed jobs')
        require(lane['protocol_ok'] == manifest['protocol_ok'] and
                lane['qualification_passed'] == manifest['qualification_passed'], variant + ' terminal gates')
    comparison = run.json('comparison.json')
    require(comparison['protocol_ok'] == manifest['protocol_ok'] and
            comparison['qualification_passed'] == manifest['qualification_passed'], 'comparison terminal gates')
    by_key = {(g['fixture_id'], g['engine'], g['mode']): g for g in comparison['groups']}
    for key, values in sorted(groups.items()):
        variant, fixture, engine, mode = key
        g = by_key[(fixture, engine, mode)][variant]
        qualified = all(j['summary']['complete'] and
            j['summary']['accepted_samples'] == j['summary']['expected_samples'] and
            not j['parse_errors'] and not j['summary']['acceptance_disagreements'] and
            not j['summary']['adapter_exception_samples'] for j in values)
        require(g['qualified_latency'] == qualified, str(key) + ' latency eligibility')
        row = dict(variant=variant, fixture=fixture, engine=engine, mode=mode,
            jobs=len(values), qualified_latency=qualified)
        for stat in ['p50', 'p95']:
            vals = [j['summary']['accepted_' + stat + '_ms'] for j in values]
            value = statistics.median(vals) if qualified else None
            require(value == g['median_process_accepted_' + stat + '_ms'], str(key) + ' median ' + stat)
            row['median_process_accepted_' + stat + '_ms'] = value
        report['groups'].append(row)
    work_counters = ['iterations', 'linear_solves', 'linear_iterations',
        'residual_evaluations', 'jacobian_evaluations', 'jacobian_nonzeros',
        'active_coordinates']
    work_comparison = collections.defaultdict(collections.Counter)
    matched_ratios = collections.defaultdict(list)
    for key, pair in pairs.items():
        require(set(pair) == set(manifest['variants']), str(key) + ' paired variants')
        require(len({p['physical_hash'] for p in pair.values()}) == 1, str(key) + ' paired physical requests')
        if set(pair) == {'before', 'after'}:
            before_rows = {r['index']: r for r in pair['before']['records']}
            after_rows = {r['index']: r for r in pair['after']['records']}
            counter = work_comparison[key[:3]]
            for index in before_rows.keys() & after_rows.keys():
                before, after = before_rows[index], after_rows[index]
                counter['paired_operations'] += 1
                counter['same_coordinates'] += before['coordinates'] == after['coordinates']
                counter['same_work_counters'] += all(before[k] == after[k] for k in work_counters)
            if all(x['job']['summary']['ranking_eligible'] for x in pair.values()):
                b = pair['before']['job']['summary']['accepted_p50_ms']
                a = pair['after']['job']['summary']['accepted_p50_ms']
                if b and a is not None:
                    matched_ratios[key[:3]].append(dict(round=key[3], after_over_before_p50=a / b))
    for key, g in by_key.items():
        if set(manifest['variants']) == {'before', 'after'}:
            for stat in ['p50', 'p95']:
                field = 'median_process_accepted_' + stat + '_ms'
                before, after = g['before'][field], g['after'][field]
                value = after / before if before is not None and after is not None and before > 0 else None
                require(value == g['after_over_before_' + stat], str(key) + ' published ratio ' + stat)
    report['counts'] = {variant: dict(c) for variant, c in counts.items()}
    report['run'] = {k: manifest[k] for k in ['status', 'purpose', 'rounds', 'warmups', 'samples',
                    'protocol_ok', 'qualification_passed', 'fixture_ids', 'engines', 'modes']}
    report['expected_jobs'] = expected_jobs
    report['job_outcomes'] = reports
    report['paired_work_comparison'] = [dict(fixture=k[0], engine=k[1], mode=k[2],
        **dict(v)) for k, v in sorted(work_comparison.items())]
    report['supplementary_paired_process_p50_ratios'] = [dict(fixture=k[0],
        engine=k[1], mode=k[2], rounds=sorted(v, key=lambda r:r['round']))
        for k, v in sorted(matched_ratios.items())]
    report['evidence_consistent'] = not report['errors']
    print(json.dumps(report, indent=2, allow_nan=False))
    return bool(report['errors'])


if __name__ == '__main__':
    raise SystemExit(main())
