#!/usr/bin/env python3
"""Extend the preserved raw audit with explicit reliability accounting.

This wrapper never executes solvers or changes input evidence. It keeps honest
feasible-case rejection, incomplete output and deadlines separate from evidence
integrity errors. The original finalization_audit.py remains byte-for-byte intact.
"""
import argparse
import collections
import gzip
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True)
    parser.add_argument('--prepared', required=True)
    parser.add_argument('--run', required=True)
    args = parser.parse_args()
    directory = Path(__file__).resolve().parent
    command = [sys.executable, str(directory / 'finalization_audit.py'),
               '--repo', args.repo, '--prepared', args.prepared, '--run', args.run]
    completed = subprocess.run(command, capture_output=True, text=True)
    if not completed.stdout.strip():
        raise RuntimeError('Preserved audit did not produce a report: ' + completed.stderr)
    report = json.loads(completed.stdout)
    report['audit_extension'] = {
        'purpose': 'Independently recount requested, reported, validated and missing operations, '
                   'recompute terminal gates, and verify timing suppression for unqualified groups',
        'base_exit_code': completed.returncode,
        'base_stderr': completed.stderr,
    }
    errors = report['errors']

    def require(condition, label):
        if not condition:
            errors.append(label)

    spec = importlib.util.spec_from_file_location(
        'reader_module', directory / 'independent-audit-preserved.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    run = module.Reader(path=args.run)
    manifest = run.json('manifest.json')
    comparison = run.json('comparison.json')
    counters = collections.defaultdict(collections.Counter)
    group_counters = collections.defaultdict(collections.Counter)
    outcomes = []
    all_protocol_ok = True
    all_qualified = True
    for name in sorted(n for n in run.names() if n.endswith('/job.json')):
        job = run.json(name)
        prefix = name.rsplit('/', 1)[0]
        request = json.loads(gzip.decompress(run.read(prefix + '/request.json.gz')))
        checked = run.jsonl(prefix + '/checked.jsonl.gz')
        native = []
        malformed_lines = []
        for line_index, line in enumerate(
                gzip.decompress(run.read(prefix + '/stdout.jsonl.gz')).splitlines(), 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except (ValueError, TypeError):
                malformed_lines.append(line_index)
                continue
            if not isinstance(value, dict):
                malformed_lines.append(line_index)
            elif value.get('record') != 'metadata':
                native.append(value)
        expected_indices = set(range(-request['warmups'], request['samples']))
        reported_indices = {r['index'] for r in native if type(r.get('index')) is int}
        missing_indices = sorted(expected_indices - reported_indices)
        require(reported_indices <= expected_indices, prefix + ' reported indices within request')
        require(len(reported_indices) == len(native), prefix + ' unique reported indices')
        measured = [r for r in checked if not r['warmup']]
        accepted = [r for r in checked if r['oracle']['accepted']]
        accepted_measured = [r for r in measured if r['oracle']['accepted']]
        disagreements = sum(bool(r['accepted']) != r['oracle']['accepted'] for r in checked)
        exceptions = sum(bool(r.get('adapter_error')) for r in checked)
        mismatches = sum(bool(r.get('adapter_error')) or
                         r['oracle']['accepted'] != request['fixture']['expected_feasible']
                         for r in checked)
        complete = (not job['timed_out'] and job['returncode'] == 0 and
                    not job['parse_errors'] and len(checked) == len(expected_indices))
        protocol = not job['parse_errors'] and not disagreements
        qualified = (complete and not mismatches and not exceptions and
                     len(accepted_measured) == (request['samples']
                     if request['fixture']['expected_feasible'] else 0))
        all_protocol_ok = all_protocol_ok and protocol
        all_qualified = all_qualified and qualified
        counts = dict(
            jobs=1, complete_jobs=int(complete),
            timed_out_jobs=int(job['timed_out']),
            nonzero_exit_jobs=int(job['returncode'] not in (0, None)),
            requested_operations=len(expected_indices), requested_warmups=request['warmups'],
            requested_measured_operations=request['samples'],
            reported_operations=len(native), validated_operations=len(checked),
            reported_measured_operations=sum(r.get('warmup') is False for r in native),
            malformed_output_lines=len(malformed_lines),
            missing_operations=len(missing_indices),
            missing_warmups=sum(index < 0 for index in missing_indices),
            missing_measured_operations=sum(index >= 0 for index in missing_indices),
            accepted_operations=len(accepted), accepted_measured_operations=len(accepted_measured),
            rejected_operations=len(checked) - len(accepted),
            feasible_rejected_operations=sum(request['fixture']['expected_feasible'] and
                                            not r['oracle']['accepted'] for r in checked),
            adapter_errors=exceptions, acceptance_disagreements=disagreements,
            qualification_mismatches=mismatches,
        )
        counters[job['variant']].update(counts)
        key = (job['variant'], job['fixture_id'], job['engine'], job['mode'])
        group_counters[key].update(counts)
        outcomes.append(dict(job=prefix, **counts, missing_indices=missing_indices,
                             statuses=dict(collections.Counter(r.get('status') for r in checked)),
                             protocol_ok=protocol, qualification_passed=qualified and protocol))

    actual_qualification = all_protocol_ok and all_qualified
    require(manifest['protocol_ok'] == all_protocol_ok, 'recomputed run protocol_ok')
    require(manifest['qualification_passed'] == actual_qualification,
            'recomputed run qualification_passed')
    require(comparison['protocol_ok'] == all_protocol_ok, 'recomputed comparison protocol_ok')
    require(comparison['qualification_passed'] == actual_qualification,
            'recomputed comparison qualification_passed')
    suppression = []
    for group in comparison['groups']:
        qualified_pair = all(group[variant]['qualified_latency'] for variant in manifest['variants'])
        if not qualified_pair:
            require(group['after_over_before_p50'] is None and
                    group['after_over_before_p95'] is None,
                    str((group['fixture_id'], group['engine'], group['mode'])) +
                    ' unsuccessful-pair timing ratios suppressed')
        for variant in manifest['variants']:
            lane = group[variant]
            if not lane['qualified_latency']:
                require(lane['median_process_accepted_p50_ms'] is None and
                        lane['median_process_accepted_p95_ms'] is None,
                        str((variant, group['fixture_id'], group['engine'], group['mode'])) +
                        ' unqualified successful-latency medians suppressed')
        suppression.append(dict(fixture_id=group['fixture_id'], engine=group['engine'],
                                mode=group['mode'], qualified_pair=qualified_pair,
                                qualified_variants={v: group[v]['qualified_latency']
                                                    for v in manifest['variants']},
                                after_over_before_p50=group['after_over_before_p50'],
                                after_over_before_p95=group['after_over_before_p95']))
    totals = collections.Counter()
    for counts in counters.values():
        totals.update(counts)
    report['reliability_accounting'] = dict(
        totals=dict(totals), variants={k: dict(v) for k, v in counters.items()},
        groups=[dict(variant=k[0], fixture_id=k[1], engine=k[2], mode=k[3], **dict(v))
                for k, v in sorted(group_counters.items())],
        jobs=outcomes, protocol_ok=all_protocol_ok, qualification_passed=actual_qualification,
        timing_suppression=suppression,
        interpretation='A failed feasible solve or timeout is retained as a reliability outcome. '
                       'It does not establish geometric infeasibility or an accepted solve latency.')
    report['evidence_consistent'] = not errors
    print(json.dumps(report, indent=2, allow_nan=False))
    return bool(errors)


if __name__ == '__main__':
    raise SystemExit(main())
