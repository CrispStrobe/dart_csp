#!/usr/bin/env python3
"""Independently bind archived tracked inputs to their declared Git blobs.

This supplementary check executes Git reads only; it does not run Dart,
compile an adapter, or change frozen preparation or measurement evidence.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    prepared = json.loads((args.prepared / 'prepared.json').read_text())
    report = {'schema_version': 1, 'errors': [], 'variants': {},
              'method': 'Byte equality against Git blobs; SDK/AOT SHA256; no solver execution'}

    def require(condition, label):
        if not condition:
            report['errors'].append(label)

    dart = prepared['dart']
    actual_sdk_hash = digest(Path(dart['executable']).read_bytes())
    require(actual_sdk_hash == dart['sha256'], 'current SDK bytes match preparation')
    report['dart_sha256'] = actual_sdk_hash
    archived_inputs = {}
    for variant, info in prepared['variants'].items():
        source = info['source']
        archive_bytes = (args.prepared / info['source_archive']).read_bytes()
        require(digest(archive_bytes) == info['source_archive_sha256'], variant + ': source archive hash')
        with tarfile.open(fileobj=io.BytesIO(archive_bytes)) as archive:
            members = archive.getmembers()
            require(all(member.isfile() for member in members), variant + ': regular archive members only')
            require(len({member.name for member in members}) == len(members), variant + ': unique archive members')
            content = {member.name: archive.extractfile(member).read() for member in members if member.isfile()}
        require(set(content) == set(source['source_sha256']), variant + ': exact archived input inventory')
        for name, data in content.items():
            require(digest(data) == source['source_sha256'].get(name), variant + ': archived hash ' + name)

        commit = source['source_commit']
        paths = subprocess.check_output(['git', '-C', str(args.repo), 'ls-tree', '-r',
            '--name-only', commit, '--', 'lib', 'test',
            'benchmark/solver_comparison/dart_adapter.dart',
            'benchmark/solver_comparison/dart_adapter_core.dart', 'pubspec.yaml'], text=True).splitlines()
        require(set(content) == set(paths) | {'pubspec.lock', '.dart_tool/package_config.json'},
                variant + ': commit tracked input inventory plus actual resolution inputs')
        queries = ''.join(commit + ':' + path + '\n' for path in paths).encode()
        raw = subprocess.check_output(['git', '-C', str(args.repo), 'cat-file', '--batch'], input=queries)
        stream = io.BytesIO(raw)
        for path in paths:
            header = stream.readline().decode().strip().split()
            if len(header) != 3 or header[1] != 'blob':
                raise ValueError('Missing/non-blob Git input: ' + path)
            blob = stream.read(int(header[2]))
            if stream.read(1) != b'\n':
                raise ValueError('Malformed Git batch output')
            require(content.get(path) == blob, variant + ': Git blob byte equality ' + path)
        require(stream.read() == b'', variant + ': complete Git blob batch consumed')
        binary_hash = digest((args.prepared / info['executable']).read_bytes())
        require(binary_hash == info['executable_sha256'], variant + ': current AOT bytes match preparation')
        report['variants'][variant] = {
            'source_commit': commit, 'tracked_files_verified': len(paths),
            'source_archive_sha256': digest(archive_bytes),
            'executable_sha256': binary_hash,
            'dependency_lock_sha256': digest(content['pubspec.lock']),
            'tracked_input_sha256': {path: digest(content[path]) for path in paths},
        }
        archived_inputs[variant] = content

    for name in ['pubspec.yaml', 'pubspec.lock',
                 'benchmark/solver_comparison/dart_adapter.dart',
                 'benchmark/solver_comparison/dart_adapter_core.dart']:
        require(archived_inputs['before'][name] == archived_inputs['after'][name],
                'paired package/adapter equality: ' + name)
    report['evidence_consistent'] = not report['errors']
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'evidence_consistent': report['evidence_consistent'], 'errors': report['errors'],
        'tracked_files_verified': {k: v['tracked_files_verified'] for k, v in report['variants'].items()}}))
    return bool(report['errors'])


if __name__ == '__main__':
    raise SystemExit(main())
