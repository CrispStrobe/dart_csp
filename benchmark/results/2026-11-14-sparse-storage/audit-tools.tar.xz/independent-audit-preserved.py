#!/usr/bin/env python3
"""Read-only independent audit of paired Dart preparation/run evidence.

Inputs may be local directories or tar.gz archives. With --ref, archive paths
are read from Git objects in --repo. The archived oracle is rerun; this script
does not run a solver, rewrite evidence, or require all feasible cases to pass
in a measurement cohort. Failures are counted separately from audit errors.
"""

import argparse
import collections
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import statistics
import subprocess
import tarfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Reader:
    def __init__(self, path=None, data=None):
        self.path = Path(path) if path is not None else None
        self.tar = None
        if data is not None or not self.path.is_dir():
            self.data = data if data is not None else self.path.read_bytes()
            self.tar = tarfile.open(fileobj=io.BytesIO(self.data))

    def names(self):
        if self.tar is not None:
            return [m.name for m in self.tar if m.isfile()]
        return [str(p.relative_to(self.path)) for p in self.path.rglob('*')
                if p.is_file()]

    def read(self, name):
        if self.tar is not None:
            return self.tar.extractfile(name).read()
        return (self.path / name).read_bytes()

    def json(self, name):
        return json.loads(self.read(name))

    def jsonl(self, name):
        return [json.loads(line) for line in
                gzip.decompress(self.read(name)).splitlines() if line]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--ref')
    parser.add_argument('--prepared', required=True)
    parser.add_argument('--run', required=True)
    args = parser.parse_args()
    report = {'errors': [], 'source': {}, 'counts': {}, 'groups': []}

    def require(condition, label):
        if not condition:
            report['errors'].append(label)

    def git(*arguments):
        return subprocess.check_output(['git', '-C', str(args.repo), *arguments])

    def reader(path):
        if args.ref:
            raw = git('show', args.ref + ':' + path)
            report.setdefault('archive_sha256', {})[path] = digest(raw)
            return Reader(data=raw)
        return Reader(path=path)

    prep, run = reader(args.prepared), reader(args.run)
    prepared_raw = prep.read('prepared.json')
    prepared = json.loads(prepared_raw)
    manifest = run.json('manifest.json')
    require(prepared['status'] == 'complete', 'preparation incomplete')
    require(digest(prepared_raw) == manifest['prepared_manifest_sha256'],
            'preparation manifest identity')
    harness_hashes = {}
    for name, sha in prepared['harness_sha256'].items():
        harness_hashes[name] = digest(prep.read('harness/' + name))
        require(harness_hashes[name] == sha, 'harness identity ' + name)
    require(harness_hashes == manifest['harness_sha256'], 'run harness identities')
    oracle = {}
    exec(compile(prep.read('harness/oracle.py'), 'saved-oracle.py', 'exec'), oracle)
    for variant, info in prepared['variants'].items():
        source = info['source']
        report['source'][variant] = {k: source[k] for k in (
            'source_commit', 'source_tree', 'library_tree', 'test_tree',
            'source_status')}
        raw_source = prep.read(info['source_archive'])
        require(digest(raw_source) == info['source_archive_sha256'],
                variant + ' source archive identity')
        archive = Reader(data=raw_source)
        for name, sha in source['source_sha256'].items():
            require(digest(archive.read(name)) == sha, variant + ' source ' + name)
        for key, suffix in [('source_tree', '^{tree}'),
                            ('library_tree', ':lib'), ('test_tree', ':test')]:
            actual = git('rev-parse', source['source_commit'] + suffix).decode().strip()
            require(actual == source[key], variant + ' ' + key)
        for kind in ('stdout', 'stderr'):
            require(digest(prep.read(variant + '/build.' + kind + '.log')) ==
                    info['build'][kind + '_sha256'], variant + ' build ' + kind)
        if info['executable'] in prep.names():
            require(digest(prep.read(info['executable'])) == info['executable_sha256'],
                    variant + ' executable identity')

    counts = collections.defaultdict(collections.Counter)
    groups = collections.defaultdict(list)
    for name in sorted(n for n in run.names() if n.endswith('/job.json')):
        prefix = name.rsplit('/', 1)[0] + '/'
        job = run.json(name)
        raw_request = gzip.decompress(run.read(prefix + 'request.json.gz'))
        request = json.loads(raw_request)
        require(digest(raw_request) == job['request_sha256'], name + ' request hash')
        checked = run.jsonl(prefix + 'checked.jsonl.gz')
        native = [r for r in run.jsonl(prefix + 'stdout.jsonl.gz')
                  if r.get('record') != 'metadata']
        require(len(native) == len(checked), name + ' retained native count')
        expected = list(range(-request['warmups'], request['samples']))
        complete = [r['index'] for r in native] == expected
        require(complete == job['summary']['complete'], name + ' completeness')
        variant = job['variant']
        c = counts[variant]
        c['jobs'] += 1
        c['complete_jobs'] += complete
        c['timeouts'] += job['timed_out']
        for n, saved in zip(native, checked):
            require({k: v for k, v in saved.items() if k != 'oracle'} == n,
                    name + ' native fields ' + str(n['index']))
            actual = oracle['check'](request, n)
            require(actual == saved['oracle'], name + ' oracle ' + str(n['index']))
            c['records'] += 1
            c['warmups'] += n['warmup']
            c['accepted'] += actual['accepted']
            c['adapter_errors'] += n.get('adapter_error') is not None
            c['qualification_mismatches'] += (
                actual['accepted'] != request['fixture']['expected_feasible'])
            c['contradictions_rejected'] += (
                not request['fixture']['expected_feasible'] and not actual['accepted'])
        measured = [r for r in checked if not r['warmup']]
        for label, rows in [('all', measured), ('accepted', [
                r for r in measured if r['oracle']['accepted']])]:
            for percentile, p in [('p50', .5), ('p95', .95)]:
                times = sorted(r['elapsed_ns'] / 1e6 for r in rows)
                value = times[math.ceil((len(times) - 1) * p)] if times else None
                require(job['summary'][label + '_' + percentile + '_ms'] == value,
                        name + ' percentile ' + label + '_' + percentile)
        groups[(variant, job['fixture_id'], job['engine'], job['mode'])].append(job)

    report['counts'] = {k: dict(v) for k, v in counts.items()}
    report['run'] = {k: manifest.get(k) for k in (
        'status', 'purpose', 'rounds', 'warmups', 'samples',
        'protocol_ok', 'qualification_passed')}
    for key, jobs in sorted(groups.items()):
        row = dict(zip(('variant', 'fixture', 'engine', 'mode'), key))
        row['jobs'] = len(jobs)
        row['all_measured_accepted'] = all(
            j['summary']['complete'] and j['summary']['accepted_samples'] ==
            j['summary']['expected_samples'] for j in jobs)
        for percentile in ('p50', 'p95'):
            values = [j['summary']['accepted_' + percentile + '_ms'] for j in jobs]
            row['median_process_' + percentile + '_ms'] = (
                statistics.median(values) if all(v is not None for v in values)
                else None)
        report['groups'].append(row)
    print(json.dumps(report, indent=2))
    return bool(report['errors'])


if __name__ == '__main__':
    raise SystemExit(main())
