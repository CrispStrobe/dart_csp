#!/usr/bin/env python3
"""Pin a new paired experiment's identities and policy around preserved raw audits.

No solver or timing subprocess is executed. The adjacent preserved audit chain
replays its frozen physical oracle and verifies raw/source/process evidence.
This wrapper additionally asserts the experiment selected by the caller, so a
successful audit of the wrong baseline or incomplete fixture set cannot qualify.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--prepared', required=True)
    parser.add_argument('--run', required=True)
    parser.add_argument('--expected-before', required=True)
    parser.add_argument('--expected-after', required=True)
    parser.add_argument('--expected-variants', default='before,after')
    parser.add_argument('--expected-fixtures', required=True)
    parser.add_argument('--expected-engines', default='dart_2d_analytic,dart_3d_ad')
    parser.add_argument('--expected-modes', default='cold,warm')
    parser.add_argument('--expected-rounds', type=int, required=True)
    parser.add_argument('--expected-warmups', type=int, required=True)
    parser.add_argument('--expected-samples', type=int, required=True)
    parser.add_argument('--require-qualification', action='store_true')
    parser.add_argument('--require-complete', action='store_true')
    parser.add_argument('--require-exact-pairs', action='store_true')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    command = [sys.executable, str(Path(__file__).with_name('reliability_audit.py')),
               '--repo', str(args.repo), '--prepared', args.prepared, '--run', args.run]
    completed = subprocess.run(command, capture_output=True, text=True)
    if not completed.stdout.strip():
        raise RuntimeError('Preserved audit did not return JSON: ' + completed.stderr)
    report = json.loads(completed.stdout)
    findings = []

    def require(condition, label):
        if not condition:
            findings.append(label)

    intended = {}
    for name, ref in [('before', args.expected_before), ('after', args.expected_after)]:
        expected = subprocess.check_output(['git', '-C', str(args.repo),
            'rev-parse', ref + '^{commit}'], text=True).strip()
        intended[name] = expected
        require(report['source'][name]['source_commit'] == expected,
                name + ': intended source commit')
    require(completed.returncode == 0, 'preserved audit returned success')
    require(not report['errors'], 'preserved evidence audit has no integrity errors')
    expected_lists = {
        'fixture_ids': args.expected_fixtures.split(','),
        'engines': args.expected_engines.split(','),
        'modes': args.expected_modes.split(','),
    }
    for field, values in expected_lists.items():
        require(report['run'][field] == values, 'intended ' + field)
    for field in ['rounds', 'warmups', 'samples']:
        require(report['run'][field] == getattr(args, 'expected_' + field),
                'intended ' + field)
    variants = args.expected_variants.split(',')
    require(set(report['counts']) == set(variants), 'intended run variants')
    expected_jobs = (len(variants) * len(expected_lists['fixture_ids']) *
                     len(expected_lists['engines']) * len(expected_lists['modes']) *
                     args.expected_rounds)
    require(report['expected_jobs'] == expected_jobs, 'intended job count')
    accounting = report['reliability_accounting']
    require(accounting['protocol_ok'], 'recomputed protocol gate')
    if args.require_qualification:
        require(accounting['qualification_passed'], 'required physical qualification')
    if args.require_complete:
        totals = accounting['totals']
        require(totals['reported_operations'] == totals['requested_operations'] and
                totals['validated_operations'] == totals['requested_operations'] and
                totals['missing_operations'] == 0,
                'all requested operations reported and validated')
        require(all(c['complete_jobs'] == c['jobs'] and not c['timeouts']
                    for c in report['counts'].values()), 'all jobs complete without timeout')
    pairs = report['paired_work_comparison']
    if args.require_exact_pairs:
        require(set(variants) == {'before', 'after'}, 'exact pairs require both variants')
        require(bool(pairs), 'paired evidence exists')
        require(all(p['same_coordinates'] == p['paired_operations'] and
                    p['same_work_counters'] == p['paired_operations'] for p in pairs),
                'every matched operation has exact coordinate/work parity')
        if args.require_complete or args.require_qualification:
            require(sum(p['paired_operations'] for p in pairs) ==
                    expected_jobs // 2 * (args.expected_warmups + args.expected_samples),
                    'complete matched operation inventory')
    report['followup_contract'] = {
        'intended_commits': intended, 'expected_lists': expected_lists,
        'expected_variants': variants, 'expected_jobs': expected_jobs,
        'require_qualification': args.require_qualification,
        'require_complete': args.require_complete,
        'require_exact_pairs': args.require_exact_pairs,
        'wrapper_findings': findings,
        'base_returncode': completed.returncode,
        'base_stderr': completed.stderr,
    }
    report['evidence_consistent'] = not (report['errors'] or findings)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'evidence_consistent': report['evidence_consistent'],
        'base_errors': report['errors'], 'contract_findings': findings,
        'counts': report['counts'], 'qualification_passed': accounting['qualification_passed']}))
    return 0 if report['evidence_consistent'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
