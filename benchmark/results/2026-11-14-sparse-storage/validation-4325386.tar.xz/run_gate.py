import datetime
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path('/workspace/scratch/f23bebb6afce')
REPO = ROOT / 'dart_csp'
DEST = ROOT / 'sparse-storage-work/validation'
DART = ROOT / 'runtime/dart-sdk/bin/dart'
ENV = dict(os.environ, PUB_CACHE=str(ROOT / 'runtime/pub-cache'),
           TMPDIR=str(ROOT / 'runtime/tmp'))
CORPUS = REPO / 'tool/performance_cad_tests.txt'
COMMANDS = {
    'format': [str(DART), 'format', '--output=none', '--set-exit-if-changed', '.'],
    'analyze': [str(DART), 'analyze', '--fatal-infos'],
    'native': [str(DART), 'test', '--reporter', 'expanded'],
    'portable-dart2js': [str(DART), 'test', '-p', 'node', '--compiler', 'dart2js',
                         '--reporter', 'expanded', *CORPUS.read_text().split()],
    'portable-dart2wasm': [str(DART), 'test', '-p', 'node', '--compiler', 'dart2wasm',
                           '--reporter', 'expanded', *CORPUS.read_text().split()],
    'python-comparison': [sys.executable, '-m', 'unittest', 'discover', '-s',
                          'benchmark/solver_comparison', '-p', 'test_*.py', '-v'],
    'python-tools': [sys.executable, '-m', 'unittest', 'discover', '-s', 'tool',
                     '-p', 'test_*.py', '-v'],
}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()

def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def provenance():
    return dict(commit=git('rev-parse', 'HEAD'),
                library_tree=git('rev-parse', 'HEAD:lib'),
                test_tree=git('rev-parse', 'HEAD:test'),
                source_tree=git('rev-parse', 'HEAD^{tree}'),
                source_status=git('status', '--porcelain', '--', 'lib', 'test'),
                tracked_status=git('status', '--porcelain', '--untracked-files=no'),
                library_file_sha256=digest(REPO/'lib/src/geometry/sparse_ldlt.dart'),
                storage_test_sha256=digest(REPO/'test/geometry_sparse_storage_test.dart'),
                corpus_sha256=digest(CORPUS),
                lock_sha256=digest(REPO/'pubspec.lock'))

for name in sys.argv[1:]:
    command = COMMANDS[name]
    record = dict(name=name, command=command, cwd=str(REPO),
                  environment={key: ENV[key] for key in ('PUB_CACHE', 'TMPDIR', 'PATH')},
                  compiler_sha256=digest(DART),
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  before=provenance(), stdout=name+'.stdout.log', stderr=name+'.stderr.log')
    print('Starting ' + name, flush=True)
    with (DEST/record['stdout']).open('wb') as out, (DEST/record['stderr']).open('wb') as err:
        result = subprocess.run(command, cwd=REPO, env=ENV, stdout=out, stderr=err)
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    record['exit_code'] = result.returncode
    record['after'] = provenance()
    record['stdout_sha256'] = digest(DEST/record['stdout'])
    record['stderr_sha256'] = digest(DEST/record['stderr'])
    record['frozen_source_unchanged'] = all(record['before'][key] == record['after'][key]
        for key in ('library_tree', 'test_tree', 'library_file_sha256', 'storage_test_sha256', 'corpus_sha256', 'lock_sha256')) and not record['after']['source_status']
    for stream in ('stdout', 'stderr'):
        text = (DEST/record[stream]).read_text(errors='replace')
        if stream == 'stdout':
            matches = re.findall(r'\+(\d+)(?:\s+~\d+)?(?::|\s+-\d+:) All tests passed!', text)
            if matches: record['dart_tests_passed'] = int(matches[-1])
        else:
            matches = re.findall(r'Ran (\d+) tests? in ', text)
            if matches: record['python_tests_run'] = int(matches[-1])
        if text: print(text[-1600:], flush=True)
    (DEST/(name+'.json')).write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({key: record[key] for key in ('name','exit_code','frozen_source_unchanged')}
                     | {key: record[key] for key in ('dart_tests_passed','python_tests_run') if key in record}), flush=True)
    if result.returncode or not record['frozen_source_unchanged']:
        raise SystemExit(result.returncode or 1)
