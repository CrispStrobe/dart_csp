# Saved solver benchmark analysis

This report reads saved evidence only. It does not execute solvers or reinterpret geometry using a newer oracle. Detailed job records and source manifests are in analysis.json.

## Input provenance

| Run | Suite | Source commit | Jobs present / planned | Summary file |
| --- | --- | --- | --- | --- |
| run-001 | confirm,coupled | b22bb671e505 | 16/16 | summary.json |

Input directories:

- run-001: /workspace/scratch/9a3b101dafc7/sparse-direct-timing-r1-b22bb671/after

## Completeness and physical outcomes

Accepted counts refer to the independent saved physical oracle. Native numerical success followed by physical rejection is a separate observation, not automatically an incorrect claim of hard feasibility. Missing operations and adapter exceptions receive no credit as successful rejection of contradictory inputs.

| Fixture | Engine | Mode | Complete jobs | Accepted / expected | Warmup accepted / expected | Valid rejections | Exceptions | Native success rejected | Oracle disagreements | Timeout jobs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ladder_125_components_1 | dart_2d_analytic | cold | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| ladder_125_components_1 | dart_3d_ad | cold | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| ladder_125_components_1 | dart_2d_analytic | warm | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| ladder_125_components_1 | dart_3d_ad | warm | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_2d_analytic | cold | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_3d_ad | cold | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_2d_analytic | warm | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_3d_ad | warm | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_2d_analytic | cold | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_3d_ad | cold | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_2d_analytic | warm | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_3d_ad | warm | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| laman_free_500 | dart_2d_analytic | cold | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| laman_free_500 | dart_3d_ad | cold | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| laman_free_500 | dart_2d_analytic | warm | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |
| laman_free_500 | dart_3d_ad | warm | 1/1 | 7/7 | 2/2 | 0 | 0 | 0 | 0 | 0 |

## Qualified successful-solve latency

Each value is the median of per-process accepted-sample percentiles, giving each process equal weight. It is not a percentile of pooled observations. Both columns are withheld unless every included/planned job is complete and every measured sample is accepted, without oracle disagreement or incompatible build/request conditions. Warmups are counted above but excluded from latency.

A five-sample process p95 is its largest observation under the recorded upper-order statistic method. These tables do not establish stable p99 performance.

| Fixture | Engine | Mode | Processes | Median process p50 ms | Median process p95 ms | Max finite error / tolerance | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ladder_125_components_1 | dart_2d_analytic | cold | 1 | 8.76328 | 12.6148 | 0.608885 | qualified |
| ladder_125_components_1 | dart_3d_ad | cold | 1 | 18.6921 | 25.1464 | 0.608885 | qualified |
| ladder_125_components_1 | dart_2d_analytic | warm | 1 | 5.71849 | 6.1893 | 0.904248 | qualified |
| ladder_125_components_1 | dart_3d_ad | warm | 1 | 13.5681 | 14.0105 | 0.904248 | qualified |
| ladder_25_components_1 | dart_2d_analytic | cold | 1 | 3.76475 | 4.16968 | 0.961667 | qualified |
| ladder_25_components_1 | dart_3d_ad | cold | 1 | 5.06404 | 5.73365 | 0.961667 | qualified |
| ladder_25_components_1 | dart_2d_analytic | warm | 1 | 2.33454 | 2.89557 | 0.560948 | qualified |
| ladder_25_components_1 | dart_3d_ad | warm | 1 | 4.61191 | 4.84782 | 0.560948 | qualified |
| laman_free_100 | dart_2d_analytic | cold | 1 | 3.87495 | 4.56738 | 0.984891 | qualified |
| laman_free_100 | dart_3d_ad | cold | 1 | 6.33891 | 7.31004 | 0.984891 | qualified |
| laman_free_100 | dart_2d_analytic | warm | 1 | 3.76117 | 4.40698 | 0.913674 | qualified |
| laman_free_100 | dart_3d_ad | warm | 1 | 5.53433 | 5.66371 | 0.913674 | qualified |
| laman_free_500 | dart_2d_analytic | cold | 1 | 97.6794 | 345.22 | 0.40129 | qualified |
| laman_free_500 | dart_3d_ad | cold | 1 | 314.048 | 486.231 | 0.40129 | qualified |
| laman_free_500 | dart_2d_analytic | warm | 1 | 69.496 | 146.912 | 0.619504 | qualified |
| laman_free_500 | dart_3d_ad | warm | 1 | 220.664 | 339.425 | 0.619504 | qualified |

## Reading limits

- Native adapter measurements exclude JSON, the external checker, browser/FFI integration and the full CAD application.
- Scalar coordinates are unfixed parameters before geometric constraints, not remaining DOF.
- Different sample or warmup counts per process are retained in JSON; select a consistent confirmation cohort when making a publication claim.
- Error ratios use each request tolerance. Missing/nonfinite errors are counted separately in JSON and are not silently converted into zero.
- Full manifests, binary/source hashes, archive hashes when read, per-job checksums, exclusions and optional engine metrics are in analysis.json.
