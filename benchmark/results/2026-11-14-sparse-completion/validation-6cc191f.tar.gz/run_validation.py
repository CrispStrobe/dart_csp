#!/usr/bin/env python3
"""Record unchanged-source correctness gates for the resumed sparse solver."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import subprocess
import sys
import time

WORKSPACE = Path('/workspace/scratch/9c4553992358')
ROOT = WORKSPACE / 'dart_csp'
OUTPUT = WORKSPACE / 'validation-final'
DART = WORKSPACE / 'runtime/sdk/dart-sdk/bin/dart'
ENV = os.environ.copy()
ENV.update(DART_DISABLE_ANALYTICS='true',
           PUB_CACHE=str(WORKSPACE / 'runtime/pub-cache'),
           TMPDIR=str(WORKSPACE / 'runtime/tmp'),
           XDG_CONFIG_HOME=str(WORKSPACE / 'runtime/config'))
ENV['PATH'] = str(DART.parent) + os.pathsep + ENV['PATH']
SOURCE_PATHS = ['lib', 'test', 'tool', 'benchmark/solver_comparison',
                '.github/workflows', 'pubspec.yaml', 'analysis_options.yaml',
                'dart_test.yaml']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def snapshot():
    names = subprocess.check_output(['git', 'ls-files', '-z', '--', *SOURCE_PATHS],
                                    cwd=ROOT).decode().split('\0')
    files = {name: sha((ROOT / name).read_bytes()) for name in sorted(names) if name}
    files['pubspec.lock'] = sha((ROOT / 'pubspec.lock').read_bytes())
    files['.dart_tool/package_config.json'] = sha((ROOT / '.dart_tool/package_config.json').read_bytes())
    return dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'),
                library_tree=git('rev-parse', 'HEAD:lib'),
                test_tree=git('rev-parse', 'HEAD:test'),
                comparison_tree=git('rev-parse', 'HEAD:benchmark/solver_comparison'),
                status=git('status', '--porcelain'),
                relevant_status=git('status', '--porcelain', '--', *SOURCE_PATHS),
                file_count=len(files), file_sha256=files,
                source_digest=sha(json.dumps(files,sort_keys=True,separators=(',', ':')).encode()))


def save(manifest, phase):
    path = OUTPUT / f'{phase}-validation.json'
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(manifest, indent=2) + '\n')
    temporary.replace(path)


def run(name, command, timeout, manifest, phase):
    print(json.dumps({'starting': name, 'utc': now()}), flush=True)
    command = [str(x) for x in command]
    before = snapshot()
    entry = dict(name=name, command=command, cwd=str(ROOT), timeout_seconds=timeout,
                 command_sha256=sha(json.dumps(command, separators=(',', ':')).encode()),
                 started_utc=now(), source_before=before)
    manifest['commands'].append(entry)
    save(manifest,phase)
    started = time.monotonic()
    out, err = OUTPUT / f'{name}.stdout.log', OUTPUT / f'{name}.stderr.log'
    with out.open('wb') as stdout, err.open('wb') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr,
                                   start_new_session=True)
        timed_out = False
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
    text = out.read_text(errors='replace') + '\n' + err.read_text(errors='replace')
    dart_count = re.search(r'\+(\d+)[^\n]*All tests passed!', text)
    python_count = re.search(r'Ran (\d+) tests? in ', text)
    count = int((dart_count or python_count).group(1)) if dart_count or python_count else None
    after = snapshot()
    entry.update(completed_utc=now(), elapsed_seconds=time.monotonic()-started,
                 exit_code=code, timed_out=timed_out, tests_passed=count if code == 0 else None,
                 stdout_file=out.name, stdout_sha256=sha(out.read_bytes()),
                 stdout_bytes=out.stat().st_size,
                 stderr_file=err.name, stderr_sha256=sha(err.read_bytes()),
                 stderr_bytes=err.stat().st_size,
                 source_after=after,
                 source_bytes_unchanged=before['file_sha256']==after['file_sha256'])
    save(manifest,phase)
    print(json.dumps({'completed':name,'exit_code':code,'tests_passed':entry['tests_passed'],
                      'seconds':entry['elapsed_seconds'],'source_bytes_unchanged':entry['source_bytes_unchanged']}),flush=True)
    if code or not entry['source_bytes_unchanged']:
        print(text[-6000:],flush=True)
    return code == 0 and not timed_out and entry['source_bytes_unchanged']


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=['python','dart'])
    phase=parser.parse_args().phase
    selected_path=ROOT/'tool/performance_cad_tests.txt'
    selected=[line.strip() for line in selected_path.read_text().splitlines()
              if line.strip() and not line.lstrip().startswith('#')]
    assert len(selected)==len(set(selected))
    assert {'test/geometry_sparse_ldlt_test.dart','test/geometry_sparse_policy_test.dart'} <= set(selected)
    manifest=dict(schema_version=1,purpose='Sparse solver correctness validation; not performance evidence',
                  phase=phase,started_utc=now(),source=snapshot(),
                  dart_version=subprocess.check_output([str(DART),'--version'],text=True,env=ENV).strip(),
                  node_version=subprocess.check_output(['node','--version'],text=True,env=ENV).strip(),
                  python_version=platform.python_version(),platform=platform.platform(),
                  runtime_sha256={'dart':sha(DART.read_bytes()),'node':sha(Path(shutil.which('node')).read_bytes())},
                  environment={key:ENV[key] for key in ('DART_DISABLE_ANALYTICS','PUB_CACHE','TMPDIR','XDG_CONFIG_HOME')},
                  runner_sha256=sha(Path(__file__).read_bytes()),commands=[],
                  portable_corpus=dict(file=str(selected_path.relative_to(ROOT)),files=selected,
                                       file_count=len(selected),sha256=sha(selected_path.read_bytes())),
                  browser=dict(rerun=False,covered=False,
                               reason='Chromium smoke aborted before tests: process-singleton socket Operation not permitted',
                               runtime_evidence_file='runtime-setup-evidence.json',
                               stderr_file='chrome-smoke.stderr.log'))
    save(manifest,phase)
    if phase=='python':
        gates=[('python_comparison',[sys.executable,'-m','unittest','discover','-s','benchmark/solver_comparison','-p','test_*.py','-v'],180)]
    else:
        gates=[('format',[DART,'format','--output=none','--set-exit-if-changed','.'],180),
               ('analysis',[DART,'analyze','--fatal-infos'],300),
               ('native',[DART,'test','--reporter','expanded'],900)]
        for compiler in ('dart2js','dart2wasm'):
            gates.append((compiler,[DART,'test','-p','node','--compiler',compiler,'--reporter','expanded',*selected],1800))
    good=True
    for name,command,timeout in gates:
        if not run(name,command,timeout,manifest,phase):
            good=False
            break
    manifest.update(completed_utc=now(),final_source=snapshot(),passed=good)
    manifest['source_bytes_unchanged']=manifest['source']['file_sha256']==manifest['final_source']['file_sha256']
    manifest['passed']=manifest['passed'] and manifest['source_bytes_unchanged'] and len(manifest['commands'])==len(gates)
    save(manifest,phase)
    print(json.dumps({'finished':True,'phase':phase,'passed':manifest['passed']}),flush=True)
    return 0 if manifest['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
