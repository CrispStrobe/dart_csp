# Sparse solver correctness validation

Source commit: `6cc191f3e9a7c6642afa9af7757b26e515723018`.

Formatting (227 files, 0 changes), fatal-info analysis, 1,862 native tests, 541 JavaScript tests, 541 WebAssembly tests, and 48 Python comparison tests passed. The portable runs used the 50 files listed in `tool/performance_cad_tests.txt`, including both sparse-solver test files.

Every command retained complete stdout/stderr, command and stream hashes, runtime identity, and source-byte hashes before and after. The source bytes remained unchanged. The Python gate began before the source commit was published; its tested bytes match the committed Dart gates exactly. These are correctness results, not latency measurements.

Real-browser assertions remain unverified. The separately recorded Chromium smoke launch aborted before tests because process-singleton socket creation is denied by this environment. See `runtime-setup-evidence.json` and `chrome-smoke.stderr.log`.

`summary.json` provides the compact gate table. `python-validation.json` and `dart-validation.json` contain detailed provenance. `run_validation.py` is the exact local runner; its absolute workspace paths describe this execution and need adapting for a new checkout.
