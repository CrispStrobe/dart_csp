# Saved solver benchmark analysis

This report reads saved evidence only. It does not execute solvers or reinterpret geometry using a newer oracle. Detailed job records and source manifests are in analysis.json.

## Input provenance

| Run | Suite | Source commit | Jobs present / planned | Summary file |
| --- | --- | --- | --- | --- |
| run-001 | smoke,confirm,coupled | 6cc191f3e9a7 | 36/36 | summary.json |

Input directories:

- run-001: /workspace/scratch/9c4553992358/sparse-final/qualification/after

## Completeness and physical outcomes

Accepted counts refer to the independent saved physical oracle. Native numerical success followed by physical rejection is a separate observation, not automatically an incorrect claim of hard feasibility. Missing operations and adapter exceptions receive no credit as successful rejection of contradictory inputs.

| Fixture | Engine | Mode | Complete jobs | Accepted / expected | Warmup accepted / expected | Valid rejections | Exceptions | Native success rejected | Oracle disagreements | Timeout jobs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| axis_rectangle | dart_2d_analytic | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| axis_rectangle | dart_3d_ad | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| axis_rectangle | dart_2d_analytic | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| axis_rectangle | dart_3d_ad | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| canonical_cell | dart_2d_analytic | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| canonical_cell | dart_3d_ad | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| canonical_cell | dart_2d_analytic | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| canonical_cell | dart_3d_ad | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| coincidence | dart_2d_analytic | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| coincidence | dart_3d_ad | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| coincidence | dart_2d_analytic | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| coincidence | dart_3d_ad | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| contradictory_distance | dart_2d_analytic | cold | 1/1 | 0/2 | 0/1 | 2 | 0 | 0 | 0 | 0 |
| contradictory_distance | dart_3d_ad | cold | 1/1 | 0/2 | 0/1 | 2 | 0 | 0 | 0 | 0 |
| contradictory_distance | dart_2d_analytic | warm | 1/1 | 0/2 | 0/1 | 2 | 0 | 0 | 0 | 0 |
| contradictory_distance | dart_3d_ad | warm | 1/1 | 0/2 | 0/1 | 2 | 0 | 0 | 0 | 0 |
| ladder_125_components_1 | dart_2d_analytic | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_125_components_1 | dart_3d_ad | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_125_components_1 | dart_2d_analytic | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_125_components_1 | dart_3d_ad | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_1_components_1_scale_1e-06 | dart_2d_analytic | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_1_components_1_scale_1e-06 | dart_3d_ad | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_1_components_1_scale_1e-06 | dart_2d_analytic | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_1_components_1_scale_1e-06 | dart_3d_ad | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_3_components_1 | dart_2d_analytic | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_3_components_1 | dart_3d_ad | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_3_components_1 | dart_2d_analytic | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_3_components_1 | dart_3d_ad | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_500_components_1 | dart_2d_analytic | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_500_components_1 | dart_3d_ad | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_500_components_1 | dart_2d_analytic | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| ladder_500_components_1 | dart_3d_ad | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| laman_free_500 | dart_2d_analytic | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| laman_free_500 | dart_3d_ad | cold | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| laman_free_500 | dart_2d_analytic | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |
| laman_free_500 | dart_3d_ad | warm | 1/1 | 2/2 | 1/1 | 0 | 0 | 0 | 0 | 0 |

## Qualified successful-solve latency

Each value is the median of per-process accepted-sample percentiles, giving each process equal weight. It is not a percentile of pooled observations. Both columns are withheld unless every included/planned job is complete and every measured sample is accepted, without oracle disagreement or incompatible build/request conditions. Warmups are counted above but excluded from latency.

A five-sample process p95 is its largest observation under the recorded upper-order statistic method. These tables do not establish stable p99 performance.

| Fixture | Engine | Mode | Processes | Median process p50 ms | Median process p95 ms | Max finite error / tolerance | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| axis_rectangle | dart_2d_analytic | cold | 1 | 0.075723 | 0.075723 | 0.0389711 | qualified |
| axis_rectangle | dart_3d_ad | cold | 1 | 0.21493 | 0.21493 | 0.0389711 | qualified |
| axis_rectangle | dart_2d_analytic | warm | 1 | 0.029294 | 0.029294 | 0.00764584 | qualified |
| axis_rectangle | dart_3d_ad | warm | 1 | 0.089503 | 0.089503 | 0.00764584 | qualified |
| canonical_cell | dart_2d_analytic | cold | 1 | 0.048863 | 0.048863 | 0.10458 | qualified |
| canonical_cell | dart_3d_ad | cold | 1 | 0.158817 | 0.158817 | 0.10458 | qualified |
| canonical_cell | dart_2d_analytic | warm | 1 | 0.03334 | 0.03334 | 0.176533 | qualified |
| canonical_cell | dart_3d_ad | warm | 1 | 0.071506 | 0.071506 | 0.176533 | qualified |
| coincidence | dart_2d_analytic | cold | 1 | 0.015964 | 0.015964 | 0.470777 | qualified |
| coincidence | dart_3d_ad | cold | 1 | 0.070935 | 0.070935 | 0.000417818 | qualified |
| coincidence | dart_2d_analytic | warm | 1 | 0.003075 | 0.003075 | 0.470777 | qualified |
| coincidence | dart_3d_ad | warm | 1 | 0.003396 | 0.003396 | 0.000417818 | qualified |
| contradictory_distance | dart_2d_analytic | cold | 1 | — | — | 1.003e+06 | expected_infeasible, not_all_measured_samples_accepted |
| contradictory_distance | dart_3d_ad | cold | 1 | — | — | 1.003e+06 | expected_infeasible, not_all_measured_samples_accepted |
| contradictory_distance | dart_2d_analytic | warm | 1 | — | — | 1.003e+06 | expected_infeasible, not_all_measured_samples_accepted |
| contradictory_distance | dart_3d_ad | warm | 1 | — | — | 1.003e+06 | expected_infeasible, not_all_measured_samples_accepted |
| ladder_125_components_1 | dart_2d_analytic | cold | 1 | 8.77588 | 8.77588 | 0.608885 | qualified |
| ladder_125_components_1 | dart_3d_ad | cold | 1 | 22.747 | 22.747 | 0.608885 | qualified |
| ladder_125_components_1 | dart_2d_analytic | warm | 1 | 5.29354 | 5.29354 | 0.752306 | qualified |
| ladder_125_components_1 | dart_3d_ad | warm | 1 | 20.8114 | 20.8114 | 0.752306 | qualified |
| ladder_1_components_1_scale_1e-06 | dart_2d_analytic | cold | 1 | 0.062413 | 0.062413 | 0.10458 | qualified |
| ladder_1_components_1_scale_1e-06 | dart_3d_ad | cold | 1 | 0.070896 | 0.070896 | 0.10458 | qualified |
| ladder_1_components_1_scale_1e-06 | dart_2d_analytic | warm | 1 | 0.021021 | 0.021021 | 0.176533 | qualified |
| ladder_1_components_1_scale_1e-06 | dart_3d_ad | warm | 1 | 0.057936 | 0.057936 | 0.176533 | qualified |
| ladder_3_components_1 | dart_2d_analytic | cold | 1 | 0.206547 | 0.206547 | 0.982742 | qualified |
| ladder_3_components_1 | dart_3d_ad | cold | 1 | 0.44327 | 0.44327 | 0.982742 | qualified |
| ladder_3_components_1 | dart_2d_analytic | warm | 1 | 0.170804 | 0.170804 | 0.569946 | qualified |
| ladder_3_components_1 | dart_3d_ad | warm | 1 | 0.305716 | 0.305716 | 0.569946 | qualified |
| ladder_500_components_1 | dart_2d_analytic | cold | 1 | 64.3625 | 64.3625 | 0.426307 | qualified |
| ladder_500_components_1 | dart_3d_ad | cold | 1 | 145.095 | 145.095 | 0.426307 | qualified |
| ladder_500_components_1 | dart_2d_analytic | warm | 1 | 27.5872 | 27.5872 | 0.960911 | qualified |
| ladder_500_components_1 | dart_3d_ad | warm | 1 | 94.9263 | 94.9263 | 0.960911 | qualified |
| laman_free_500 | dart_2d_analytic | cold | 1 | 83.7566 | 83.7566 | 0.401286 | qualified |
| laman_free_500 | dart_3d_ad | cold | 1 | 138.614 | 138.614 | 0.401286 | qualified |
| laman_free_500 | dart_2d_analytic | warm | 1 | 64.8686 | 64.8686 | 0.729569 | qualified |
| laman_free_500 | dart_3d_ad | warm | 1 | 129.827 | 129.827 | 0.729569 | qualified |

## Partial or rejected results: descriptive only

These statistics retain completed observations from excluded groups. They must not be ranked as successful-solve latency. An accepted subset can be easier than the missing or rejected operations. Process timeouts are whole-job limits.

| Fixture | Engine | Mode | Observed / expected | Accepted subset processes | Available accepted p50 ms | Available accepted p95 ms | All-observation p50 ms |
| --- | --- | --- | --- | --- | --- | --- | --- |
| contradictory_distance | dart_2d_analytic | cold | 2/2 | 0 | — | — | 0.09398 |
| contradictory_distance | dart_3d_ad | cold | 2/2 | 0 | — | — | 0.347407 |
| contradictory_distance | dart_2d_analytic | warm | 2/2 | 0 | — | — | 0.075373 |
| contradictory_distance | dart_3d_ad | warm | 2/2 | 0 | — | — | 0.198315 |

## Contradictory fixtures

Valid rejection means a checked emitted physical rejection without an adapter exception. It is not a mathematical infeasibility certificate.

| Fixture | Engine | Mode | Valid rejected / expected | Complete valid-rejection jobs | All jobs validly rejected |
| --- | --- | --- | --- | --- | --- |
| contradictory_distance | dart_2d_analytic | cold | 2/2 | 1/1 | True |
| contradictory_distance | dart_3d_ad | cold | 2/2 | 1/1 | True |
| contradictory_distance | dart_2d_analytic | warm | 2/2 | 1/1 | True |
| contradictory_distance | dart_3d_ad | warm | 2/2 | 1/1 | True |

## Reading limits

- Native adapter measurements exclude JSON, the external checker, browser/FFI integration and the full CAD application.
- Scalar coordinates are unfixed parameters before geometric constraints, not remaining DOF.
- Different sample or warmup counts per process are retained in JSON; select a consistent confirmation cohort when making a publication claim.
- Error ratios use each request tolerance. Missing/nonfinite errors are counted separately in JSON and are not silently converted into zero.
- Full manifests, binary/source hashes, archive hashes when read, per-job checksums, exclusions and optional engine metrics are in analysis.json.
