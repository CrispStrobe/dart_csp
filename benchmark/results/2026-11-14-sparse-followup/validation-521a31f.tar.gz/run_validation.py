"""Run and atomically preserve validation of the frozen ordering candidate."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

root = Path('/workspace/scratch/a4f67f49ccab')
repo = root / 'followup-order'
out = root / 'ordering-results/validation'
out.mkdir(parents=True, exist_ok=True)
dart = root / 'runtime/dart-sdk/bin/dart'
env = {**os.environ, 'TMPDIR': str(root / 'runtime/tmp'),
       'PUB_CACHE': str(root / 'runtime/pub-cache'),
       'PATH': str(dart.parent) + ':' + os.environ['PATH']}
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo).decode().strip()
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
state = {'schema_version': 1, 'source_commit': git('rev-parse', 'HEAD'),
         'library_tree': git('rev-parse', 'HEAD:lib'),
         'test_tree': git('rev-parse', 'HEAD:test'), 'status': 'running',
         'started_utc': now(), 'gates': [], 'browser_covered': False,
         'browser_note': 'Node portability is distinct from browser execution; prior local Chromium startup failed before assertions.'}
def save():
    temp = out / 'summary.json.tmp'
    temp.write_text(json.dumps(state, indent=2) + '\n')
    temp.replace(out / 'summary.json')
save()
portable = [line.strip() for line in (repo / 'tool/performance_cad_tests.txt').read_text().splitlines()
            if line.strip() and not line.startswith('#')]
commands = [
    ('format', [str(dart), 'format', '--output=none', '--set-exit-if-changed', '.']),
    ('analysis', [str(dart), 'analyze', '--fatal-infos']),
    ('python_comparison', [sys.executable, '-m', 'unittest', 'discover', '-s', 'benchmark/solver_comparison', '-p', 'test_*.py']),
    ('native', [str(dart), 'test', '--reporter', 'expanded']),
    ('dart2js', [str(dart), 'test', '-p', 'node', '--compiler', 'dart2js', '--reporter', 'expanded', *portable]),
    ('dart2wasm', [str(dart), 'test', '-p', 'node', '--compiler', 'dart2wasm', '--reporter', 'expanded', *portable]),
]
for name, command in commands:
    start = time.monotonic()
    record = {'name': name, 'command': command, 'started_utc': now()}
    state['in_progress'] = name
    save()
    with (out / (name + '.stdout.log')).open('wb') as stdout, (out / (name + '.stderr.log')).open('wb') as stderr:
        completed = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr)
    log = (out / (name + '.stdout.log')).read_text(errors='replace') + (out / (name + '.stderr.log')).read_text(errors='replace')
    match = re.findall(r'\+(\d+): All tests passed!', log) or re.findall(r'Ran (\d+) tests?', log)
    record.update(exit_code=completed.returncode, elapsed_seconds=time.monotonic() - start,
                  completed_utc=now(), tests_passed=int(match[-1]) if match and completed.returncode == 0 else None)
    for stream in ('stdout', 'stderr'):
        p = out / (name + '.' + stream + '.log')
        record[stream] = {'file': p.name, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    state['gates'].append(record)
    save()
    print(name, completed.returncode, record['tests_passed'], flush=True)
    if completed.returncode:
        state['status'] = 'failed'
        state.pop('in_progress', None)
        save()
        raise SystemExit(completed.returncode)
assert not git('status', '--porcelain', '--', 'lib', 'test')
state.update(status='completed', completed_utc=now(), source_bytes_unchanged=True,
             portable_corpus_count=len(portable), portable_corpus_sha256=hashlib.sha256((repo / 'tool/performance_cad_tests.txt').read_bytes()).hexdigest())
state.pop('in_progress', None)
save()
