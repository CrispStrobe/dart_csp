# Saved solver benchmark analysis

This report reads saved evidence only. It does not execute solvers or reinterpret geometry using a newer oracle. Detailed job records and source manifests are in analysis.json.

## Input provenance

| Run | Suite | Source commit | Jobs present / planned | Summary file |
| --- | --- | --- | --- | --- |
| run-001 | confirm,coupled | 521a31f78989 | 24/24 | summary.json |

Input directories:

- run-001: /workspace/scratch/a4f67f49ccab/ordering-results/small-controls/after

## Completeness and physical outcomes

Accepted counts refer to the independent saved physical oracle. Native numerical success followed by physical rejection is a separate observation, not automatically an incorrect claim of hard feasibility. Missing operations and adapter exceptions receive no credit as successful rejection of contradictory inputs.

| Fixture | Engine | Mode | Complete jobs | Accepted / expected | Warmup accepted / expected | Valid rejections | Exceptions | Native success rejected | Oracle disagreements | Timeout jobs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ladder_25_components_1 | dart_2d_analytic | cold | 3/3 | 21/21 | 6/6 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_3d_ad | cold | 3/3 | 21/21 | 6/6 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_2d_analytic | warm | 3/3 | 21/21 | 6/6 | 0 | 0 | 0 | 0 | 0 |
| ladder_25_components_1 | dart_3d_ad | warm | 3/3 | 21/21 | 6/6 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_2d_analytic | cold | 3/3 | 21/21 | 6/6 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_3d_ad | cold | 3/3 | 21/21 | 6/6 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_2d_analytic | warm | 3/3 | 21/21 | 6/6 | 0 | 0 | 0 | 0 | 0 |
| laman_free_100 | dart_3d_ad | warm | 3/3 | 21/21 | 6/6 | 0 | 0 | 0 | 0 | 0 |

## Qualified successful-solve latency

Each value is the median of per-process accepted-sample percentiles, giving each process equal weight. It is not a percentile of pooled observations. Both columns are withheld unless every included/planned job is complete and every measured sample is accepted, without oracle disagreement or incompatible build/request conditions. Warmups are counted above but excluded from latency.

A five-sample process p95 is its largest observation under the recorded upper-order statistic method. These tables do not establish stable p99 performance.

| Fixture | Engine | Mode | Processes | Median process p50 ms | Median process p95 ms | Max finite error / tolerance | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ladder_25_components_1 | dart_2d_analytic | cold | 3 | 2.84078 | 5.19334 | 0.961667 | qualified |
| ladder_25_components_1 | dart_3d_ad | cold | 3 | 4.77372 | 5.90468 | 0.961667 | qualified |
| ladder_25_components_1 | dart_2d_analytic | warm | 3 | 2.43812 | 3.44074 | 0.560948 | qualified |
| ladder_25_components_1 | dart_3d_ad | warm | 3 | 3.94711 | 4.86029 | 0.560948 | qualified |
| laman_free_100 | dart_2d_analytic | cold | 3 | 3.67735 | 4.67935 | 0.984891 | qualified |
| laman_free_100 | dart_3d_ad | cold | 3 | 5.74492 | 6.34241 | 0.984891 | qualified |
| laman_free_100 | dart_2d_analytic | warm | 3 | 3.50888 | 3.96079 | 0.913674 | qualified |
| laman_free_100 | dart_3d_ad | warm | 3 | 5.81488 | 6.23528 | 0.913674 | qualified |

## Reading limits

- Native adapter measurements exclude JSON, the external checker, browser/FFI integration and the full CAD application.
- Scalar coordinates are unfixed parameters before geometric constraints, not remaining DOF.
- Different sample or warmup counts per process are retained in JSON; select a consistent confirmation cohort when making a publication claim.
- Error ratios use each request tolerance. Missing/nonfinite errors are counted separately in JSON and are not silently converted into zero.
- Full manifests, binary/source hashes, archive hashes when read, per-job checksums, exclusions and optional engine metrics are in analysis.json.
