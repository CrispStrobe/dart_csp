import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/workspace/scratch/822c041c6436/dart_csp')
evidence = root.parent / 'audit-evidence'
name = sys.argv[1]
sdk = root.parent / 'toolchain/dart-sdk/bin'
env = dict(os.environ)
env.update(PUB_CACHE=str(root.parent / 'pub-cache'),
           TMPDIR=str(root.parent / 'tmp'), DART_DISABLE_ANALYTICS='true')
env['PATH'] = str(sdk) + os.pathsep + env.get('PATH', '')
env['CHROME_EXECUTABLE'] = str(root.parent / 'toolchain/chrome-test.sh')
portable = (root / 'tool/performance_cad_tests.txt').read_text().split()
commands = {
    'native': ['dart', 'test', '--reporter', 'expanded', '--concurrency=4'],
    'javascript': ['dart', 'test', '-p', 'node', '--compiler', 'dart2js',
                   '--reporter', 'expanded', '--concurrency=2', *portable],
    'wasm': ['dart', 'test', '-p', 'node', '--compiler', 'dart2wasm',
             '--reporter', 'expanded', '--concurrency=2', *portable],
    'static': ['bash', '-c', 'dart format --output=none --set-exit-if-changed . && dart analyze --fatal-infos'],
    'browser': ['dart', 'test', '-p', 'chrome', '--reporter', 'expanded',
                '--timeout=45s', '--concurrency=1', 'test/lcg/atom_boundary_test.dart'],
}
command = commands[name]
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
record = {'name': name, 'command': command, 'cwd': str(root),
          'source': {'commit': git('rev-parse', 'HEAD'),
                     'library_tree': git('rev-parse', 'HEAD:lib'),
                     'test_tree': git('rev-parse', 'HEAD:test'),
                     'library_diff': git('diff', '--name-only', 'HEAD', '--', 'lib', 'test')},
          'dependency_lock_sha256': hashlib.sha256((root / 'pubspec.lock').read_bytes()).hexdigest(),
          'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
log = evidence / (name + '.log')
start = time.monotonic()
with log.open('wb') as out:
    try:
        code = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=subprocess.STDOUT,
                              timeout=1200 if name != 'browser' else 150).returncode
    except subprocess.TimeoutExpired:
        code = 124
        out.write(b'\nValidation runner deadline exceeded.\n')
record.update(exit_code=code, elapsed_seconds=time.monotonic()-start,
              finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              log_file=log.name, log_bytes=log.stat().st_size,
              log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(evidence / (name + '.json')).write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(code)
