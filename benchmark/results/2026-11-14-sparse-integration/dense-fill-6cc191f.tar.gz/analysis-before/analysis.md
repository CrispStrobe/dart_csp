# Saved solver benchmark analysis

This report reads saved evidence only. It does not execute solvers or reinterpret geometry using a newer oracle. Detailed job records and source manifests are in analysis.json.

## Input provenance

| Run | Suite | Source commit | Jobs present / planned | Summary file |
| --- | --- | --- | --- | --- |
| run-001 | coupled | 135a6eed93b4 | 4/4 | summary.json |

Input directories:

- run-001: /workspace/scratch/636979d9dc25/integration-evidence/dense-fill-reliability/before

## Completeness and physical outcomes

Accepted counts refer to the independent saved physical oracle. Native numerical success followed by physical rejection is a separate observation, not automatically an incorrect claim of hard feasibility. Missing operations and adapter exceptions receive no credit as successful rejection of contradictory inputs.

| Fixture | Engine | Mode | Complete jobs | Accepted / expected | Warmup accepted / expected | Valid rejections | Exceptions | Native success rejected | Oracle disagreements | Timeout jobs |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| laman_free_2000 | dart_2d_analytic | cold | 1/1 | 0/2 | 0/0 | 2 | 0 | 0 | 0 | 0 |
| laman_free_2000 | dart_3d_ad | cold | 1/1 | 0/2 | 0/0 | 2 | 0 | 0 | 0 | 0 |
| laman_free_2000 | dart_2d_analytic | warm | 1/1 | 0/2 | 0/0 | 2 | 0 | 0 | 0 | 0 |
| laman_free_2000 | dart_3d_ad | warm | 1/1 | 0/2 | 0/0 | 2 | 0 | 0 | 0 | 0 |

## Qualified successful-solve latency

Each value is the median of per-process accepted-sample percentiles, giving each process equal weight. It is not a percentile of pooled observations. Both columns are withheld unless every included/planned job is complete and every measured sample is accepted, without oracle disagreement or incompatible build/request conditions. Warmups are counted above but excluded from latency.

A five-sample process p95 is its largest observation under the recorded upper-order statistic method. These tables do not establish stable p99 performance.

| Fixture | Engine | Mode | Processes | Median process p50 ms | Median process p95 ms | Max finite error / tolerance | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| laman_free_2000 | dart_2d_analytic | cold | 1 | — | — | 8.18002 | not_all_measured_samples_accepted |
| laman_free_2000 | dart_3d_ad | cold | 1 | — | — | 8.18002 | not_all_measured_samples_accepted |
| laman_free_2000 | dart_2d_analytic | warm | 1 | — | — | 8.18002 | not_all_measured_samples_accepted |
| laman_free_2000 | dart_3d_ad | warm | 1 | — | — | 8.18002 | not_all_measured_samples_accepted |

## Partial or rejected results: descriptive only

These statistics retain completed observations from excluded groups. They must not be ranked as successful-solve latency. An accepted subset can be easier than the missing or rejected operations. Process timeouts are whole-job limits.

| Fixture | Engine | Mode | Observed / expected | Accepted subset processes | Available accepted p50 ms | Available accepted p95 ms | All-observation p50 ms |
| --- | --- | --- | --- | --- | --- | --- | --- |
| laman_free_2000 | dart_2d_analytic | cold | 2/2 | 0 | — | — | 4730.31 |
| laman_free_2000 | dart_3d_ad | cold | 2/2 | 0 | — | — | 7742.51 |
| laman_free_2000 | dart_2d_analytic | warm | 2/2 | 0 | — | — | 4592.99 |
| laman_free_2000 | dart_3d_ad | warm | 2/2 | 0 | — | — | 7310.56 |

## Reading limits

- Native adapter measurements exclude JSON, the external checker, browser/FFI integration and the full CAD application.
- Scalar coordinates are unfixed parameters before geometric constraints, not remaining DOF.
- Different sample or warmup counts per process are retained in JSON; select a consistent confirmation cohort when making a publication claim.
- Error ratios use each request tolerance. Missing/nonfinite errors are counted separately in JSON and are not silently converted into zero.
- Full manifests, binary/source hashes, archive hashes when read, per-job checksums, exclusions and optional engine metrics are in analysis.json.
